Supplementary package manifest

Python scripts

* S1.py
* S2.py
* S3.py
* S4.py

MATLAB scripts

* tree.m
* matrix.m
* daily.m
* fit\_EK\_from\_daily\_confirmed1.m

Input data

* cases\_raw.csv
* traj\_raw.csv
* nodes.csv
* edges.csv
* tree\_age.csv

Intermediate or derived data

* cases\_T1.csv
* candidates.csv
* tree\_full.csv
* final\_parameters.csv

Main correspondence to manuscript

* Figure 1(a): tree.m
* Figure 1(b): matrix.m
* Figure 2(b): daily.m
* Figure 3: fit\_EK\_from\_daily\_confirmed1.m
* Appendix B pipeline: S1.py, S2.py, S3.py, S4.py

Notation mapping

* g in code = m in manuscript
* EK in code = E(K) in manuscript

