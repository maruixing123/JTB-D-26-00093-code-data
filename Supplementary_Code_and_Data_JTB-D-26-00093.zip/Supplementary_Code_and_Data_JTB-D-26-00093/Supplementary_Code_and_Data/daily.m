clear; clc; close all;

%% Data
dateLabels = { ...
    '2021.7.28','2021.7.29','2021.7.30','2021.7.31', ...
    '2021.8.1','2021.8.2','2021.8.3','2021.8.4','2021.8.5','2021.8.6', ...
    '2021.8.7','2021.8.8','2021.8.9','2021.8.10','2021.8.11','2021.8.12', ...
    '2021.8.13','2021.8.14','2021.8.15','2021.8.16','2021.8.17','2021.8.18', ...
    '2021.8.19','2021.8.20','2021.8.21','2021.8.22','2021.8.23','2021.8.24', ...
    '2021.8.25','2021.8.26'};

confirmedCases = [ ...
     2,  4, 10, 12, 26, 40, 32, 36, 58, 52, ...
    36, 38, 48, 54, 37, 25, 18, 18,  6,  3, ...
     6,  3,  2,  1,  1,  0,  0,  1,  0,  1];

%% Figure
fig = figure('Color','w','Position',[100 80 1500 760]);

ax = axes('Parent', fig);
hold(ax, 'on');

% Background color
bgColor = [0.94 0.94 0.94];
set(ax, 'Color', bgColor);

%% Bar chart
b = bar(ax, confirmedCases, 0.8);
b.FaceColor = [0.22 0.60 0.80];
b.EdgeColor = [0.18 0.34 0.44];
b.LineWidth = 1.1;

%% Axes style
ax.Box = 'off';
ax.LineWidth = 1.2;
ax.FontSize = 13;
ax.XColor = [0.45 0.45 0.45];
ax.YColor = [0.45 0.45 0.45];
ax.TickDir = 'out';     
ax.TickLength = [0.015 0.015];

ax.XTick = 1:numel(dateLabels);
ax.XTickLabel = dateLabels;
ax.XTickLabelRotation = 45;

ax.YLim = [0 60];
ax.YTick = 0:10:60;

xlabel('Date', 'FontSize', 16, 'Color', [0.35 0.35 0.35]);
ylabel('Number of Confirmed Cases', 'FontSize', 16, 'Color', [0.35 0.35 0.35]);

%% Value labels
for i = 1:numel(confirmedCases)
    if confirmedCases(i) > 0
        text(i, confirmedCases(i) + 0.6, num2str(confirmedCases(i)), ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'bottom', ...
            'FontSize', 12, ...
            'Color', [0.35 0.35 0.35]);
    end
end

%% Save as PNG for MATLAB R2019b
set(fig, 'PaperPositionMode', 'auto');
print(fig, 'daily_confirmed_cases_yangzhou', '-dpng', '-r600');