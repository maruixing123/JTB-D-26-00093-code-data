clear; clc; close all

%% =========================
%  Parameters
%% =========================
nodesFile  = 'nodes.csv';
edgesFile  = 'edges.csv';

rootCase   = '1';
showLabels = 0;
rng(2);

%% =========================
%  1) Read node file
%  Col 1 = Case ID
%  Col 2 = Detection method
%% =========================
nodes_ok = 0;
try
    Tn = readtable(nodesFile, 'PreserveVariableNames', true);
    rawNodeID = Tn{:,1};
    rawMethod = Tn{:,2};
    nodes_ok = 1;
catch
end

if nodes_ok == 0
    fid = -1;
    try
        fid = fopen(nodesFile, 'r', 'n', 'UTF-8');
    catch
    end
    if fid < 0
        fid = fopen(nodesFile, 'r');
    end
    if fid < 0
        error(['Cannot open ', nodesFile]);
    end

    Cn = textscan(fid, '%s%s%s%s%s', ...
        'Delimiter', ',', ...
        'HeaderLines', 1, ...
        'ReturnOnError', 0);
    fclose(fid);

    rawNodeID = Cn{1};
    rawMethod = Cn{2};
end

%% =========================
%  2) Read edge file
%% =========================
edges_ok = 0;
try
    Te = readtable(edgesFile, 'PreserveVariableNames', true);
    rawFrom = Te{:,1};
    rawTo   = Te{:,2};
    edges_ok = 1;
catch
end

if edges_ok == 0
    fid = -1;
    try
        fid = fopen(edgesFile, 'r', 'n', 'UTF-8');
    catch
    end
    if fid < 0
        fid = fopen(edgesFile, 'r');
    end
    if fid < 0
        error(['Cannot open ', edgesFile]);
    end

    Ce = textscan(fid, '%s%s', ...
        'Delimiter', ',', ...
        'HeaderLines', 1, ...
        'ReturnOnError', 0);
    fclose(fid);

    rawFrom = Ce{1};
    rawTo   = Ce{2};
end

%% =========================
%  3) Convert to cell strings
%% =========================
% nodeID
if isnumeric(rawNodeID)
    nodeID = cell(length(rawNodeID),1);
    for i = 1:length(rawNodeID)
        nodeID{i} = num2str(rawNodeID(i));
    end
elseif iscell(rawNodeID)
    nodeID = cell(length(rawNodeID),1);
    for i = 1:length(rawNodeID)
        if isnumeric(rawNodeID{i})
            nodeID{i} = num2str(rawNodeID{i});
        else
            nodeID{i} = strtrim(char(rawNodeID{i}));
        end
    end
else
    tmp = cellstr(rawNodeID);
    nodeID = tmp(:);
end

% method
if isnumeric(rawMethod)
    methodCell = cell(length(rawMethod),1);
    for i = 1:length(rawMethod)
        methodCell{i} = num2str(rawMethod(i));
    end
elseif iscell(rawMethod)
    methodCell = cell(length(rawMethod),1);
    for i = 1:length(rawMethod)
        if isempty(rawMethod{i})
            methodCell{i} = '';
        elseif isnumeric(rawMethod{i})
            methodCell{i} = num2str(rawMethod{i});
        else
            methodCell{i} = strtrim(char(rawMethod{i}));
        end
    end
else
    tmp = cellstr(rawMethod);
    methodCell = tmp(:);
end

% from
if isnumeric(rawFrom)
    fromID = cell(length(rawFrom),1);
    for i = 1:length(rawFrom)
        fromID{i} = num2str(rawFrom(i));
    end
elseif iscell(rawFrom)
    fromID = cell(length(rawFrom),1);
    for i = 1:length(rawFrom)
        if isnumeric(rawFrom{i})
            fromID{i} = num2str(rawFrom{i});
        else
            fromID{i} = strtrim(char(rawFrom{i}));
        end
    end
else
    tmp = cellstr(rawFrom);
    fromID = tmp(:);
end

% to
if isnumeric(rawTo)
    toID = cell(length(rawTo),1);
    for i = 1:length(rawTo)
        toID{i} = num2str(rawTo(i));
    end
elseif iscell(rawTo)
    toID = cell(length(rawTo),1);
    for i = 1:length(rawTo)
        if isnumeric(rawTo{i})
            toID{i} = num2str(rawTo{i});
        else
            toID{i} = strtrim(char(rawTo{i}));
        end
    end
else
    tmp = cellstr(rawTo);
    toID = tmp(:);
end

%% =========================
%  4) Keep only Case 1 and its descendants
%% =========================
keepMap = containers.Map;
queue = {rootCase};

while ~isempty(queue)
    cur = queue{1};
    queue(1) = [];

    if isKey(keepMap, cur)
        continue
    end
    keepMap(cur) = 1;

    idx = strcmp(fromID, cur);
    children = toID(idx);

    for j = 1:length(children)
        c = children{j};
        if ~isKey(keepMap, c)
            queue{end+1} = c;
        end
    end
end

edgeKeep = false(length(fromID),1);
for i = 1:length(fromID)
    if isKey(keepMap, fromID{i}) && isKey(keepMap, toID{i})
        edgeKeep(i) = true;
    end
end

fromKeep = fromID(edgeKeep);
toKeep   = toID(edgeKeep);

%% =========================
%  5) Build detection-method map
%% =========================
methodMap = containers.Map;
for i = 1:length(nodeID)
    key = nodeID{i};
    val = methodCell{i};
    methodMap(key) = val;
end

%% =========================
%  6) Build graph
%% =========================
G = graph(fromKeep, toKeep);

if findnode(G, rootCase) == 0
    G = addnode(G, rootCase);
end

nodeNames = G.Nodes.Name;
n = numnodes(G);

%% =========================
%  7) Generate detection-method categories
%% =========================
methodNames = {'Case 1'};

for i = 1:n
    thisID = nodeNames{i};

    if strcmp(thisID, rootCase)
        continue
    end

    if isKey(methodMap, thisID)
        thisMethod = strtrim(methodMap(thisID));
    else
        thisMethod = '';
    end

    if isempty(thisMethod)
        continue
    end

    found = 0;
    for k = 1:length(methodNames)
        if strcmp(methodNames{k}, thisMethod)
            found = 1;
            break
        end
    end

    if found == 0
        methodNames{end+1} = thisMethod;
    end
end

disp('Detection methods included in the figure:');
disp(methodNames');

%% =========================
%  8) Color map
%% =========================
medium_colors = [ ...
    1.00, 0.90, 0.30; ...
    0.30, 0.60, 0.90; ...
    0.90, 0.30, 0.30; ...
    1.00, 0.60, 0.30; ...
    0.60, 0.30, 0.90; ...
    0.30, 0.80, 0.60; ...
    0.90, 0.60, 0.30; ...
    0.70, 0.70, 0.70; ...
    0.90, 0.50, 0.70; ...
    0.50, 0.80, 0.30];

baseColors = medium_colors;
m = length(methodNames);

if m <= size(baseColors,1)
    cmap = baseColors(1:m,:);
else
    extra = lines(m - size(baseColors,1));
    cmap = [baseColors; extra];
end

%% =========================
%  9) English legend labels
%% =========================
methodNamesEN = cell(size(methodNames));

for k = 1:m
    thisName = strtrim(methodNames{k});

    if strcmp(thisName, 'Case 1')
        methodNamesEN{k} = 'Case 1';
    elseif strcmpi(thisName, 'contact tracing')
        methodNamesEN{k} = 'contact tracing';
    elseif strcmpi(thisName, 'diagnosis')
        methodNamesEN{k} = 'diagnosis';
    elseif strcmpi(thisName, 'mass screening')
        methodNamesEN{k} = 'mass screening';
    else
        % ���ԭ���ﱾ������Ӣ�ģ�ֱ�ӱ���
        methodNamesEN{k} = thisName;
    end
end

%% =========================
%  10) Group nodes by detection method
%% =========================
groupNodes = cell(m,1);
unknownCases = {};

for i = 1:n
    thisID = nodeNames{i};

    if strcmp(thisID, rootCase)
        thisMethod = 'Case 1';
    else
        if isKey(methodMap, thisID)
            thisMethod = strtrim(methodMap(thisID));
        else
            thisMethod = '';
        end
    end

    gid = 0;
    for k = 1:m
        if strcmp(methodNames{k}, thisMethod)
            gid = k;
            break
        end
    end

    if gid == 0
        unknownCases{end+1} = thisID;
        continue
    end

    groupNodes{gid} = [groupNodes{gid}, i];
end

if ~isempty(unknownCases)
    disp('Cases without detection method:');
    disp(unknownCases');
else
    disp('No cases with missing detection method.');
end

%% =========================
%  11) Plot main graph
%% =========================
bgColor = [0.92 0.92 0.92];

fig = figure('Color', bgColor);
set(fig, 'Position', [80 80 1450 1000]);

axMain = axes('Parent', fig);
set(axMain, 'Color', bgColor);

if showLabels == 1
    labels = nodeNames;
else
    labels = repmat({''}, n, 1);
end

p = plot(axMain, G, ...
    'Layout', 'force', ...
    'NodeLabel', labels);

axis(axMain, 'off');

p.Marker = 'o';
p.MarkerSize = 3.5;
p.LineWidth = 0.6;
p.EdgeColor = [0.72 0.72 0.72];
p.NodeColor = [0.82 0.82 0.82];

for k = 1:m
    if ~isempty(groupNodes{k})
        highlight(p, groupNodes{k}, ...
            'NodeColor', cmap(k,:), ...
            'MarkerSize', 4.0);
    end
end

rootIdx = findnode(G, rootCase);
if rootIdx > 0
    highlight(p, rootIdx, ...
        'NodeColor', [0.95 0.82 0.10], ...
        'MarkerSize', 8);
end

title(axMain, ['Transmission Network from Case ', rootCase, ...
    ' (Colored by Detection Method)'], ...
    'FontSize', 14, 'FontWeight', 'bold');


mainPos = get(axMain, 'Position');
set(axMain, 'Position', [mainPos(1) mainPos(2) 0.76 mainPos(4)]);

%% =========================
%% =========================
axLeg = axes('Parent', fig, ...
    'Position', [0.81 0.22 0.17 0.25], ...
    'Color', bgColor, ...
    'XColor', 'none', ...
    'YColor', 'none', ...
    'Box', 'off');

hold(axLeg, 'on');
xlim(axLeg, [0 1]);
ylim(axLeg, [0 m+1]);
set(axLeg, 'Visible', 'off');

for k = 1:m
    y = m - k + 1;

    plot(axLeg, 0.08, y, 'o', ...
        'MarkerSize', 7, ...
        'MarkerFaceColor', cmap(k,:), ...
        'MarkerEdgeColor', [0.30 0.30 0.30]);

    text(axLeg, 0.16, y, methodNamesEN{k}, ...
        'FontSize', 11, ...
        'Interpreter', 'none', ...
        'VerticalAlignment', 'middle', ...
        'HorizontalAlignment', 'left', ...
        'Color', [0.1 0.1 0.1]);
end

%% =========================
%% =========================
set(fig, 'PaperPositionMode', 'auto');
try
    exportgraphics(fig, 'transmission_network_case1_detection_method.png', 'Resolution', 600);
catch
    try
        print(fig, 'transmission_network_case1_detection_method', '-dpng', '-r600');
    catch
        saveas(fig, 'transmission_network_case1_detection_method.png');
    end
end

disp('Done: transmission_network_case1_detection_method.png has been saved.');
