"""
S3.py (English dataset, CSV format)
Main parameter estimation and sensitivity analysis.
Reads tree_full.csv (from S2) and merges with cases_T1.csv for full data.
"""

import pandas as pd
import numpy as np
import re
import os
from scipy.stats import weibull_min, expon, uniform, lognorm, kstest
import warnings
warnings.filterwarnings('ignore')

# ==================== Fixed parameters ====================
INCUBATION_SHAPE = 1.83
INCUBATION_SCALE = 4.93
incubation_dist = weibull_min(c=INCUBATION_SHAPE, scale=INCUBATION_SCALE)
Q95_INCUBATION = incubation_dist.ppf(0.95)

GAMMA = 0.2

# ==================== Column names ====================
COL_CASE_ID = 'case_id'
COL_PARENT = 'parent_id'
COL_ISOLATION = 'quarantine date'
COL_CONFIRM = 'confirmation date'
COL_SYMPTOM = 'symptom onset date'
COL_ROUTE = 'route'
COL_C_NUM = 'C_num'
COL_O_NUM = 'O_num'
COL_HAS_ONSET = 'has_onset'

def clean_parent_id(val):
    if pd.isna(val):
        return 0
    val_str = str(val).strip()
    if any(sep in val_str for sep in ['、', ',', '，', ' ']):
        numbers = re.findall(r'\d+', val_str)
        return int(numbers[0]) if numbers else 0
    try:
        return int(float(val_str))
    except ValueError:
        return 0

def load_complete_data(tree_path, cases_T1_path):
    """
    Load tree_full.csv and merge with cases_T1.csv to get route, dates, etc.
    """
    # Load tree data (has case_id, parent_id, C_num, O_num, has_onset)
    df_tree = pd.read_csv(tree_path, encoding='utf-8-sig')
    # Load original case data (contains route, dates, etc.)
    df_cases = pd.read_csv(cases_T1_path, encoding='utf-8-sig')

    # Merge on case_id, keeping all columns from tree and adding needed ones from cases
    df = df_tree.merge(df_cases[[COL_CASE_ID, COL_ROUTE, COL_ISOLATION, COL_CONFIRM, COL_SYMPTOM]],
                       on=COL_CASE_ID, how='left')

    # Clean parent_id (should already be integer from S2, but ensure)
    df[COL_PARENT] = df[COL_PARENT].apply(clean_parent_id)

    # Parse dates
    for col in [COL_ISOLATION, COL_CONFIRM, COL_SYMPTOM]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # Route classification
    def classify_route(route):
        if pd.isna(route):
            return 'other'
        route = str(route).strip().lower()
        if route in ['diagnosis', 'screening', 'tracing']:
            return route
        return 'other'
    df['route3'] = df[COL_ROUTE].apply(classify_route)

    # Build children mapping
    children = {cid: [] for cid in df[COL_CASE_ID]}
    for _, row in df.iterrows():
        pid = row[COL_PARENT]
        if pid != 0 and pid in children:
            children[pid].append(row[COL_CASE_ID])
    df['children'] = df[COL_CASE_ID].map(children)

    # Ensure C_num, O_num, has_onset exist (from tree)
    if COL_C_NUM not in df.columns or COL_O_NUM not in df.columns:
        t0 = pd.Timestamp('2021-07-20')
        df['C_date'] = df[COL_ISOLATION].fillna(df[COL_CONFIRM])
        df['O_date'] = df[COL_SYMPTOM]
        df[COL_C_NUM] = (df['C_date'] - t0).dt.days
        df[COL_O_NUM] = (df['O_date'] - t0).dt.days
    if COL_HAS_ONSET not in df.columns:
        df[COL_HAS_ONSET] = df[COL_SYMPTOM].notna()

    earliest_onset = df.loc[df[COL_HAS_ONSET], COL_O_NUM].min() if df[COL_HAS_ONSET].any() else df[COL_C_NUM].min() - 5.0
    return df, earliest_onset

# ==================== Infection time reconstruction (unchanged) ====================
def reconstruct_infection_times(df, beta_hat=None, use_exp_prior=False,
                                warn_counts=None, t_intro=None,
                                delta=0.5, R=7.0, gamma=GAMMA):
    if warn_counts is None:
        warn_counts = {'onset_failed': 0, 'invalid_interval': 0, 'exp_failed': 0}
    T_dict = {}
    processed = set()

    def process_case(cid):
        if cid in processed:
            return
        row = df[df[COL_CASE_ID] == cid].iloc[0]
        parent_id = row[COL_PARENT]
        if parent_id != 0 and parent_id not in processed:
            process_case(parent_id)
        C_i = row[COL_C_NUM]
        has_onset = row[COL_HAS_ONSET]
        O_i = row[COL_O_NUM] if has_onset else None
        if has_onset:
            max_attempts = 1000
            attempts = 0
            success = False
            while attempts < max_attempts:
                L = incubation_dist.rvs()
                T_cand = O_i - L
                if T_cand > t_intro and T_cand <= C_i:
                    if parent_id != 0:
                        T_parent = T_dict[parent_id]
                        if T_cand >= T_parent + delta:
                            T_dict[cid] = T_cand
                            success = True
                            break
                    else:
                        T_dict[cid] = T_cand
                        success = True
                        break
                attempts += 1
            if not success:
                warn_counts['onset_failed'] += 1
                T_dict[cid] = C_i - delta
        else:
            if parent_id == 0:
                low = max(t_intro, C_i - R)
                high = C_i - delta
            else:
                T_parent = T_dict[parent_id]
                low = T_parent + delta
                high = C_i
            if low >= high:
                warn_counts['invalid_interval'] += 1
                T_dict[cid] = high - 0.01
            else:
                if use_exp_prior and beta_hat is not None and parent_id != 0:
                    rate = beta_hat + gamma
                    max_attempts = 1000
                    attempts = 0
                    success = False
                    while attempts < max_attempts:
                        X = expon.rvs(scale=1/rate)
                        T_cand = T_parent + X
                        if low <= T_cand <= high:
                            T_dict[cid] = T_cand
                            success = True
                            break
                        attempts += 1
                    if not success:
                        warn_counts['exp_failed'] += 1
                        T_dict[cid] = uniform.rvs(loc=low, scale=high-low)
                else:
                    T_dict[cid] = uniform.rvs(loc=low, scale=high-low)
        processed.add(cid)

    roots = df[df[COL_PARENT] == 0][COL_CASE_ID].tolist()
    non_roots = df[df[COL_PARENT] != 0][COL_CASE_ID].tolist()
    for cid in roots + non_roots:
        process_case(cid)
    return T_dict, warn_counts

def estimate_beta(df, T_dict, gamma=GAMMA):
    deltas = []
    for _, row in df.iterrows():
        pid = row[COL_PARENT]
        if pid != 0:
            deltas.append(T_dict[row[COL_CASE_ID]] - T_dict[pid])
    if not deltas:
        return np.nan
    mean_delta = np.mean(deltas)
    return max(0, 1/mean_delta - gamma)

def estimate_hazard_diagnosis(df, T_dict):
    tau_vals = []
    for _, row in df[df['route3'] == 'diagnosis'].iterrows():
        tau = row[COL_C_NUM] - T_dict[row[COL_CASE_ID]]
        if tau > 0:
            tau_vals.append(tau)
    if len(tau_vals) < 2:
        return np.nan, np.nan, None, np.nan
    shape, loc, scale = lognorm.fit(tau_vals, floc=0)
    mu = np.log(scale)
    sigma = shape
    ks_stat, p_value = kstest(tau_vals, 'lognorm', args=(sigma, 0, scale))
    def h_d(tau):
        pdf = lognorm.pdf(tau, s=sigma, scale=scale)
        cdf = lognorm.cdf(tau, s=sigma, scale=scale)
        return pdf / (1 - cdf)
    return mu, sigma, h_d, p_value

def estimate_g_screening(df, T_dict):
    tau_vals = []
    for _, row in df[df['route3'] == 'screening'].iterrows():
        tau = row[COL_C_NUM] - T_dict[row[COL_CASE_ID]]
        if tau > 0:
            tau_vals.append(tau)
    if not tau_vals:
        return np.nan
    return len(tau_vals) / np.sum(tau_vals)

def estimate_epsilon_tracing(df, T_dict, W=5.0):
    eligible = 0
    success = 0
    for _, row in df.iterrows():
        cid = row[COL_CASE_ID]
        T_i = T_dict[cid]
        C_i = row[COL_C_NUM]
        neighbors = [row[COL_PARENT]] + row['children']
        is_eligible = False
        for nb in neighbors:
            if nb == 0 or nb not in T_dict:
                continue
            C_k = df.loc[df[COL_CASE_ID] == nb, COL_C_NUM].values[0]
            if 0 < C_k - T_i <= W and C_i > C_k:
                is_eligible = True
                break
        if is_eligible:
            eligible += 1
            if row['route3'] == 'tracing':
                success += 1
    return success / eligible if eligible > 0 else np.nan

def run_single_reconstruction(df, earliest_onset, beta_init=None,
                              delta=0.5, R=7.0, gamma=GAMMA, W=5.0, n_iter=2):
    t_intro = earliest_onset - Q95_INCUBATION
    warn_counts = {'onset_failed': 0, 'invalid_interval': 0, 'exp_failed': 0}
    T_dict, _ = reconstruct_infection_times(
        df, beta_hat=beta_init, use_exp_prior=(beta_init is not None),
        warn_counts=warn_counts, t_intro=t_intro, delta=delta, R=R, gamma=gamma
    )
    beta_hat = estimate_beta(df, T_dict, gamma=gamma)
    for _ in range(1, n_iter):
        T_dict, _ = reconstruct_infection_times(
            df, beta_hat=beta_hat, use_exp_prior=True,
            warn_counts=warn_counts, t_intro=t_intro, delta=delta, R=R, gamma=gamma
        )
        beta_hat = estimate_beta(df, T_dict, gamma=gamma)
    g_hat = estimate_g_screening(df, T_dict)
    epsilon_hat = estimate_epsilon_tracing(df, T_dict, W=W)
    mu_d, sigma_d, _, ks_p = estimate_hazard_diagnosis(df, T_dict)
    return T_dict, beta_hat, g_hat, epsilon_hat, mu_d, sigma_d, ks_p

def run_main_analysis(df, earliest_onset, M=200, n_iter=2,
                      W=5.0, delta=0.5, R=7.0, gamma=GAMMA, verbose=True):
    results = {'beta': [], 'g': [], 'epsilon': [], 'mu_d': [], 'sigma_d': [], 'ks_p': []}
    for m in range(M):
        if verbose and (m+1) % 20 == 0:
            print(f"  Progress {m+1}/{M}")
        _, beta, g, eps, mu, sigma, ks_p = run_single_reconstruction(
            df, earliest_onset, beta_init=None, delta=delta, R=R, gamma=gamma, W=W, n_iter=n_iter
        )
        results['beta'].append(beta)
        results['g'].append(g)
        results['epsilon'].append(eps)
        results['mu_d'].append(mu)
        results['sigma_d'].append(sigma)
        results['ks_p'].append(ks_p)
    return pd.DataFrame(results)

def summarize_results(df_res):
    summary = {}
    for col in ['beta', 'g', 'epsilon']:
        arr = df_res[col].dropna().values
        if len(arr):
            summary[col] = {
                'median': np.median(arr),
                'ci_lower': np.percentile(arr, 2.5),
                'ci_upper': np.percentile(arr, 97.5)
            }
    mu_vals = df_res['mu_d'].dropna().values
    sigma_vals = df_res['sigma_d'].dropna().values
    if len(mu_vals):
        summary['mu_med'] = np.median(mu_vals)
        summary['sigma_med'] = np.median(sigma_vals)
        ks_vals = df_res['ks_p'].dropna().values
        if len(ks_vals):
            summary['ks_p_median'] = np.median(ks_vals)
    return summary

def sensitivity_analysis(df, earliest_onset, base_M=100, samples_dir=None):
    param_grid = {'W': [3, 5, 7], 'delta': [0.25, 0.5, 1.0], 'R': [5, 7, 10, 14]}
    sens_results = {}
    for param_name, values in param_grid.items():
        print(f"\nSensitivity analysis: {param_name}")
        summaries = []
        for val in values:
            print(f"  {param_name} = {val}")
            kwargs = {'W': 5.0, 'delta': 0.5, 'R': 7.0, 'gamma': GAMMA}
            kwargs[param_name] = val
            mu_list = []
            sigma_list = []
            df_res = pd.DataFrame()
            for _ in range(base_M):
                _, beta, g, eps, mu, sigma, ks_p = run_single_reconstruction(
                    df, earliest_onset, beta_init=None,
                    delta=kwargs['delta'], R=kwargs['R'],
                    gamma=kwargs['gamma'], W=kwargs['W'], n_iter=2
                )
                if not np.isnan(mu) and not np.isnan(sigma):
                    mu_list.append(mu)
                    sigma_list.append(sigma)
                df_res = pd.concat([df_res, pd.DataFrame({
                    'beta': [beta], 'g': [g], 'epsilon': [eps],
                    'mu_d': [mu], 'sigma_d': [sigma], 'ks_p': [ks_p]
                })], ignore_index=True)
            summ = summarize_results(df_res)
            row = {'param_value': val}
            for p in ['beta', 'g', 'epsilon']:
                if p in summ:
                    row[f'{p}_median'] = summ[p]['median']
                    row[f'{p}_lower'] = summ[p]['ci_lower']
                    row[f'{p}_upper'] = summ[p]['ci_upper']
            summaries.append(row)

            if samples_dir is not None and len(mu_list) > 0:
                os.makedirs(samples_dir, exist_ok=True)
                sample_df = pd.DataFrame({'mu_d': mu_list, 'sigma_d': sigma_list})
                sample_file = os.path.join(samples_dir, f"mu_sigma_samples_{param_name}_{val}.csv")
                sample_df.to_csv(sample_file, index=False)
                print(f"    Samples saved to: {sample_file}")

        sens_results[param_name] = pd.DataFrame(summaries)
    return sens_results

if __name__ == "__main__":
    # ========== Adjust paths as needed ==========
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    tree_path = os.path.join(data_dir, "tree_full.csv")
    cases_T1_path = os.path.join(data_dir, "cases_T1.csv")
    out_res = os.path.join(data_dir, "results_main.csv")
    out_sens_dir = data_dir
    samples_dir = os.path.join(data_dir, "samples")

    print("=" * 60)
    print("Loading and merging data...")
    df, earliest_onset = load_complete_data(tree_path, cases_T1_path)
    print(f"Cases: {len(df)}, roots (parent_id=0): {(df[COL_PARENT]==0).sum()}")

    # Main analysis (M=500)
    print("\n" + "=" * 60)
    print("Running main analysis (M=500)")
    df_main = run_main_analysis(df, earliest_onset, M=500, n_iter=3, gamma=GAMMA, verbose=True)
    df_main.to_csv(out_res, index=False, encoding='utf-8-sig')
    print(f"Main results saved to: {out_res}")

    summary = summarize_results(df_main)
    print("\n=== Parameter estimates (median [95% CI]) ===")
    for p in ['beta', 'g', 'epsilon']:
        if p in summary:
            s = summary[p]
            print(f"{p}: {s['median']:.4f} [{s['ci_lower']:.4f}, {s['ci_upper']:.4f}]")
    if 'mu_med' in summary:
        print(f"mu_d: {summary['mu_med']:.4f}, sigma_d: {summary['sigma_med']:.4f}")

    # Save main samples
    os.makedirs(samples_dir, exist_ok=True)
    df_main[['mu_d', 'sigma_d']].dropna().to_csv(
        os.path.join(samples_dir, "mu_sigma_samples_main.csv"), index=False)
    print(f"Main samples saved to: {samples_dir}/mu_sigma_samples_main.csv")

    # Sensitivity analysis (tables + samples)
    print("\n" + "=" * 60)
    print("Running sensitivity analysis (M=200 each) and saving samples")
    sens_dict = sensitivity_analysis(df, earliest_onset, base_M=200, samples_dir=samples_dir)
    for param, df_sens in sens_dict.items():
        out_sens_file = os.path.join(out_sens_dir, f"results_sens_{param}.csv")
        df_sens.to_csv(out_sens_file, index=False, encoding='utf-8-sig')
        print(f"Sensitivity table for {param} saved to: {out_sens_file}")

    print("\nAll analyses complete.")