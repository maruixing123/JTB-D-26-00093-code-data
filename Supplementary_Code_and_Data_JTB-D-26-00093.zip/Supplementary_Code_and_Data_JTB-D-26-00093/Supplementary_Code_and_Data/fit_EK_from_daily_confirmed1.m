function results = fit_EK_from_daily_confirmed1_revised(counts, pars)


    if nargin < 1 || isempty(counts)
        % Six daily counts corresponding to 2021-07-28 ... 2021-08-02
        counts = [2; 4; 10; 12; 26; 40];
    end
    counts = counts(:);

    if nargin < 2 || isempty(pars)
        pars = default_pars_local();
    else
        pars = fill_default_pars_local(pars);
    end

    validate_inputs_local(counts, pars);

    t = (0:numel(counts)-1)';

    % Direct Poisson log-linear fit for lambda, as a descriptive proxy.
    [lambda_proxy_hat, lambda_proxy_CI, A_proxy_hat] = fit_lambda_proxy_local(counts, t);

    % Main MLE over E(K), profiling out A.
    objEK = @(EK) profile_nll_local(EK, t, counts, pars);
    [EK_hat, nll_min] = fminbnd(objEK, pars.EK_lb, pars.EK_ub);
    [nll_min, A_hat, lambda_hat] = profile_nll_local(EK_hat, t, counts, pars);

    % Profile-likelihood scan.
    EK_grid = linspace(pars.EK_lb, pars.EK_ub, pars.EK_grid_n);
    nll_prof = nan(size(EK_grid));
    A_prof = nan(size(EK_grid));
    lambda_prof = nan(size(EK_grid));

    for k = 1:numel(EK_grid)
        [nll_prof(k), A_prof(k), lambda_prof(k)] = profile_nll_local(EK_grid(k), t, counts, pars);
    end

    chi2_95_df1 = 3.84145882069412;
    cutoff_nll = nll_min + 0.5 * chi2_95_df1;
    cutoff_dev = chi2_95_df1;

    inside = (nll_prof <= cutoff_nll);
    if any(inside)
        EK_CI_profile = [min(EK_grid(inside)), max(EK_grid(inside))];
        ci_hit_boundary = inside(1) || inside(end);
    else
        EK_CI_profile = [NaN, NaN];
        ci_hit_boundary = true;
    end

    % Smooth fitted mean curve for plotting.
    tfine = linspace(min(t), max(t), pars.plotFineN)';
    mu_fine = A_hat * exp(lambda_hat * tfine);

    % Collect results.
    results = struct();
    results.counts = counts;
    results.time_index = t;
    results.pars = pars;

    results.EK_hat = EK_hat;
    results.EK_CI_profile = EK_CI_profile;
    results.A_hat = A_hat;
    results.lambda_hat = lambda_hat;
    results.nll_min = nll_min;
    results.profile_cutoff_nll = cutoff_nll;
    results.profile_cutoff_dev = cutoff_dev;
    results.profile_CI_hits_boundary = ci_hit_boundary;

    results.lambda_proxy_hat = lambda_proxy_hat;
    results.lambda_proxy_CI = lambda_proxy_CI;
    results.A_proxy_hat = A_proxy_hat;

    results.mu_hat = A_hat * exp(lambda_hat * t);
    results.mu_proxy_hat = A_proxy_hat * exp(lambda_proxy_hat * t);

    results.profile_table = table(EK_grid(:), A_prof(:), lambda_prof(:), nll_prof(:), ...
        'VariableNames', {'EK', 'A_profile', 'lambda_of_EK', 'NLL_profile'});

    results.profile_deviance = 2 * (nll_prof(:) - nll_min);

    results.tfine = tfine;
    results.mu_fine = mu_fine;

    % Add stochastic predictive trajectories and pointwise predictive intervals
    % under the fitted Poisson observation model.
    results = add_predictive_simulations_local(results);

    % Print summary.
    fprintf('\n============================================================\n');
    fprintf('Estimation from early daily confirmed counts (Poisson proxy)\n');
    fprintf('============================================================\n');
    fprintf('Observed counts: ');
    fprintf('%g ', counts);
    fprintf('\n\n');

    fprintf('Direct proxy fit for lambda from counts only:\n');
    fprintf('  lambda_proxy_hat = %.6f /day\n', lambda_proxy_hat);
    fprintf('  95%% Wald CI      = [%.6f, %.6f]\n\n', lambda_proxy_CI(1), lambda_proxy_CI(2));

    fprintf('Mechanistic fit for E(K):\n');
    fprintf('  E(K)_hat         = %.6f\n', EK_hat);
    fprintf('  95%% profile CI   = [%.6f, %.6f]\n', EK_CI_profile(1), EK_CI_profile(2));
    fprintf('  A_hat            = %.6f\n', A_hat);
    fprintf('  lambda(EK_hat)   = %.6f /day\n', lambda_hat);
    if ci_hit_boundary
        fprintf('  NOTE: profile CI touches the EK search boundary. Consider enlarging pars.EK_lb / pars.EK_ub.\n');
    end
    fprintf('============================================================\n\n');

    if pars.makePlots
        make_plots_local(results);
    end
end

% =======================================================================
% Defaults and validation
% =======================================================================

function pars = default_pars_local()
    pars.beta   = 0.2653;
    pars.gamma  = 0.20;
    pars.eps    = 0.5763;
    pars.m      = 0.2684;

    % h_d(tau) from lognormal distribution.
    pars.mu_d    = 0.9420;
    pars.sigma_d = 0.8443;

    % Start date: 2021-07-28 ... 2021-08-02.
    pars.startDate = '2021-07-28';

    % Numerical settings.
    pars.tauMax = 30;
    pars.dt = 0.05;
    pars.maxIterHazard = 300;
    pars.tolHazard = 1e-6;
    pars.relaxHazard = 0.50;

    pars.lambdaL = -1.5;
    pars.lambdaU =  1.5;
    pars.lambdaExpandStep = 0.5;
    pars.lambdaExpandMax = 16;

    pars.EK_lb = 0.10;
    pars.EK_ub = 20.0;
    pars.EK_grid_n = 240;

    pars.makePlots = true;
    pars.plotFineN = 400;

    % Predictive simulation options for Fig. 3.
    pars.nSimPred  = 5000;  % number of stochastic predictive trajectories
    pars.nShowTraj = 30;    % number of randomly selected trajectories to plot
    pars.predAlpha = 0.05;  % 95% pointwise predictive interval
    pars.rngSeed   = 2026;  % random seed for reproducibility

    % Appendix plotting options.
    pars.profile_ylim = 10;      % compact y-axis for appendix figure
    pars.profile_xpad = 1.5;     % padding around CI for zoomed x-range
end

function pars = fill_default_pars_local(pars)
    def = default_pars_local();
    f = fieldnames(def);
    for i = 1:numel(f)
        if ~isfield(pars, f{i}) || isempty(pars.(f{i}))
            pars.(f{i}) = def.(f{i});
        end
    end
end

function validate_inputs_local(counts, pars)
    if any(~isfinite(counts)) || any(counts < 0) || any(abs(counts - round(counts)) > 0)
        error('counts must be a nonnegative integer vector.');
    end

    req = {'beta','gamma','eps','m','mu_d','sigma_d','startDate'};
    for i = 1:numel(req)
        if ~isfield(pars, req{i})
            error('Missing pars.%s', req{i});
        end
    end

    if pars.beta <= 0 || pars.gamma < 0 || pars.eps < 0 || pars.eps > 1 || pars.m < 0
        error('Check pars.beta>0, pars.gamma>=0, 0<=pars.eps<=1, pars.m>=0.');
    end
    if pars.sigma_d <= 0
        error('pars.sigma_d must be > 0.');
    end
    if pars.dt <= 0 || pars.tauMax <= 0
        error('pars.dt and pars.tauMax must be positive.');
    end
    if pars.plotFineN < 2
        error('pars.plotFineN must be >= 2.');
    end
    if pars.nSimPred < 1 || pars.nShowTraj < 0
        error('pars.nSimPred must be >= 1 and pars.nShowTraj must be >= 0.');
    end
    if pars.predAlpha <= 0 || pars.predAlpha >= 1
        error('pars.predAlpha must be between 0 and 1.');
    end
end

% =======================================================================
% Direct proxy fit
% =======================================================================

function [lambda_hat, lambda_CI, A_hat] = fit_lambda_proxy_local(y, t)
    obj = @(b) sum(exp(b(1) + b(2) * t) - y .* (b(1) + b(2) * t) + gammaln(y + 1));
    b0 = [log(max(mean(y), 1e-3)); 0.2];
    opts = optimset('Display', 'off');
    bhat = fminsearch(obj, b0, opts);

    alpha_hat = bhat(1);
    lambda_hat = bhat(2);
    A_hat = exp(alpha_hat);

    mu = exp(alpha_hat + lambda_hat * t);
    X = [ones(size(t)), t];
    I = X' * (X .* mu);

    if rcond(I) < 1e-12
        V = pinv(I);
    else
        V = inv(I);
    end

    se_lambda = sqrt(max(V(2,2), 0));
    lambda_CI = lambda_hat + [-1.96, 1.96] * se_lambda;
end

% =======================================================================
% Profile NLL
% =======================================================================

function [nll, A_hat, lambda_hat] = profile_nll_local(EK, t, y, pars)
    if EK <= 0 || ~isfinite(EK)
        nll = Inf;
        A_hat = NaN;
        lambda_hat = NaN;
        return;
    end

    lambda_hat = lambda_from_EK_local(EK, pars);

    b = exp(lambda_hat * t);
    denom = sum(b);
    if denom <= 0 || ~isfinite(denom)
        nll = Inf;
        A_hat = NaN;
        return;
    end

    A_hat = sum(y) / denom;
    A_hat = max(A_hat, 1e-12);

    mu = A_hat * b;
    mu = max(mu, 1e-12);

    nll = sum(mu - y .* log(mu) + gammaln(y + 1));
end

% =======================================================================
% lambda(EK)
% =======================================================================

function lambda = lambda_from_EK_local(EK, pars)
    fun = @(lam) lotka_residual_local(lam, EK, pars);

    a = pars.lambdaL;
    b = pars.lambdaU;
    fa = fun(a);
    fb = fun(b);

    expand_count = 0;
    while sign(fa) == sign(fb) && expand_count < pars.lambdaExpandMax
        a = a - pars.lambdaExpandStep;
        b = b + pars.lambdaExpandStep;
        fa = fun(a);
        fb = fun(b);
        expand_count = expand_count + 1;
    end

    opts = optimset('Display', 'off');
    if sign(fa) ~= sign(fb)
        lambda = fzero(fun, [a, b], opts);
    else
        obj = @(lam) fun(lam).^2;
        lambda = fminbnd(obj, a, b, opts);
    end
end

function val = lotka_residual_local(lambda, EK, pars)
    [tau, F3] = solve_F3_given_lambda_local(lambda, EK, pars);
    theta = EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-(pars.gamma + lambda) .* tau) .* F3;
    val = trapz(tau, integrand) - 1;
end

% =======================================================================
% Solve F3
% =======================================================================

function [tau, F3] = solve_F3_given_lambda_local(lambda, EK, pars)
    tau = (0:pars.dt:pars.tauMax)';
    n = numel(tau);

    beta = pars.beta;
    epsi = pars.eps;
    m = pars.m;

    hd = diagnosis_hazard_lognormal_local(tau, pars.mu_d, pars.sigma_d);
    z = EK * (1 - exp(-beta * tau));
    theta = EK * beta * exp(-beta * tau);

    h1 = zeros(n, 1);
    h2 = zeros(n, 1);

    for iter = 1:pars.maxIterHazard
        h1_old = h1;
        h2_old = h2;

        Fd = exp(-cumtrapz(tau, hd));
        Fm = exp(-m * tau);

        Fc1 = exp(-cumtrapz(tau, h1_old));
        Fc2 = exp(-cumtrapz(tau, z .* h2_old));

        F1 = Fc1 .* Fd .* Fm;
        F2 = Fc2 .* Fd .* Fm;

        D1 = trapz(tau, exp(-(lambda + pars.gamma) * tau) .* theta .* F1);
        D2 = trapz(tau, exp(-(lambda + pars.gamma) * tau) .* theta .* F2);
        D1 = max(D1, 1e-12);
        D2 = max(D2, 1e-12);

        h1_new = zeros(n, 1);
        Q1 = F1 .* (h1_old + hd + m);
        for i = 1:n
            tau_shift = tau(i:end);
            a = tau_shift - tau(i);
            theta_a = EK * beta * exp(-beta * a);
            integrand = exp(-(lambda + pars.gamma) * a) .* theta_a .* Q1(i:end);
            h1_new(i) = epsi / D1 * trapz_safe_local(a, integrand);
        end
        h1_new = max(h1_new, 0);

        h2_new = zeros(n, 1);
        R2 = F2 .* (z .* h2_old + hd + m);
        for i = 1:n
            b = tau(1:i);
            theta_b = EK * beta * exp(-beta * b);
            integrand = exp(-(lambda + pars.gamma) * b) .* theta_b .* flipud(R2(1:i));
            h2_new(i) = epsi / D2 * trapz_safe_local(b, integrand);
        end
        h2_new = max(h2_new, 0);

        h1 = pars.relaxHazard * h1_old + (1 - pars.relaxHazard) * h1_new;
        h2 = pars.relaxHazard * h2_old + (1 - pars.relaxHazard) * h2_new;

        err = max([norm(h1 - h1_old, inf), norm(h2 - h2_old, inf)]);
        if err < pars.tolHazard
            break;
        end
    end

    hc3 = h1 + z .* h2;
    Fd = exp(-cumtrapz(tau, hd));
    Fm = exp(-m * tau);
    Fc3 = exp(-cumtrapz(tau, hc3));
    F3 = Fc3 .* Fd .* Fm;
end

% =======================================================================
% h_d(tau)
% =======================================================================

function hd = diagnosis_hazard_lognormal_local(tau, mu, sigma)
    tau_safe = max(tau, 1e-12);

    logtau = log(tau_safe);
    pdf = exp(-((logtau - mu).^2) ./ (2 * sigma^2)) ./ (tau_safe * sigma * sqrt(2*pi));
    cdf = 0.5 * (1 + erf((logtau - mu) ./ (sigma * sqrt(2))));

    S = max(1 - cdf, 1e-12);
    hd = pdf ./ S;
    hd(tau == 0) = 0;
end

% =======================================================================
% Predictive simulations for Fig. 3
% =======================================================================

function results = add_predictive_simulations_local(results)
%ADD_PREDICTIVE_SIMULATIONS_LOCAL
% Generate stochastic predictive trajectories under the fitted Poisson
% observation model:
%
%     C_j ~ Poisson(mu_j),
%     mu_j = A_hat * exp(lambda_hat * j).
%
% These trajectories are used only for uncertainty visualization in Fig. 3.

    mu_hat = results.mu_hat(:)';
    pars = results.pars;

    rng(pars.rngSeed);

    nSim = pars.nSimPred;
    nT = numel(mu_hat);

    sim_counts = zeros(nSim, nT);

    for r = 1:nSim
        sim_counts(r, :) = local_poissrnd_vec(mu_hat);
    end

    % Pointwise predictive quantiles.
    sim_sorted = sort(sim_counts, 1);

    low_id = max(1, ceil((pars.predAlpha / 2) * nSim));
    high_id = min(nSim, floor((1 - pars.predAlpha / 2) * nSim));

    pred_low = sim_sorted(low_id, :)';
    pred_high = sim_sorted(high_id, :)';
    pred_median = median(sim_counts, 1)';

    % Randomly selected predictive trajectories for display.
    nShow = min(pars.nShowTraj, nSim);
    if nShow > 0
        show_id = randperm(nSim, nShow);
        pred_show = sim_counts(show_id, :)';
    else
        pred_show = zeros(nT, 0);
    end

    results.pred_sim_counts = sim_counts;
    results.pred_low = pred_low;
    results.pred_high = pred_high;
    results.pred_median = pred_median;
    results.pred_show = pred_show;
end

function x = local_poissrnd_vec(mu)
%LOCAL_POISSRND_VEC
% Generate independent Poisson random variables with means given by mu.
% If poissrnd is available, use it. Otherwise, use Knuth's algorithm.

    mu = mu(:)';
    x = zeros(size(mu));

    if exist('poissrnd', 'file') == 2
        x = poissrnd(mu);
        return;
    end

    % Fallback: Knuth algorithm. This is suitable here because the early
    % daily counts are moderate.
    for i = 1:numel(mu)
        lambda = mu(i);

        if lambda <= 0
            x(i) = 0;
        else
            L = exp(-lambda);
            k = 0;
            p = 1;

            while p > L
                k = k + 1;
                p = p * rand;
            end

            x(i) = k - 1;
        end
    end
end

% =======================================================================
% Plotting
% =======================================================================

function make_plots_local(results)
%MAKE_PLOTS_LOCAL
% Generate Fig. 3 and the appendix profile likelihood figure.
%
% Fig. 3 includes:
%   1. observed daily confirmed counts,
%   2. fitted mean curve,
%   3. randomly selected stochastic predictive trajectories,
%   4. pointwise 95% predictive interval under the fitted Poisson model.

    t = results.time_index;
    y = results.counts;
    tfine = results.tfine;
    mu_fine = results.mu_fine;

    % Build date labels so that x = 0 corresponds to the first observation date.
    startDate = datetime(results.pars.startDate, 'InputFormat', 'yyyy-MM-dd');
    dateTicks = startDate + days(t);

    dateLabels = cell(numel(dateTicks), 1);
    for k = 1:numel(dateTicks)
        dateLabels{k} = sprintf('%d-%d-%d', ...
            year(dateTicks(k)), month(dateTicks(k)), day(dateTicks(k)));
    end

    %% ================================================================
    %  Fig. 3: Early-growth fit with stochastic predictive uncertainty
    %  ================================================================

    figure('Name', 'Fig. 3: Early-growth fit with predictive uncertainty', 'Color', 'w');
    hold on;

    % Pointwise 95% predictive interval under the fitted Poisson observation model.
    pred_low = results.pred_low;
    pred_high = results.pred_high;

    hBand = patch([t; flipud(t)], ...
                  [pred_low; flipud(pred_high)], ...
                  [0.85 0.85 0.85], ...
                  'EdgeColor', 'none', ...
                  'FaceAlpha', 0.65, ...
                  'DisplayName', '95% predictive interval');

    % Randomly selected stochastic predictive trajectories.
    pred_show = results.pred_show;
    hTraj = [];
    for r = 1:size(pred_show, 2)
        if r == 1
            hTraj = plot(t, pred_show(:, r), '-', ...
                         'Color', [0.65 0.65 0.65], ...
                         'LineWidth', 0.6, ...
                         'DisplayName', 'Predictive trajectories');
        else
            plot(t, pred_show(:, r), '-', ...
                 'Color', [0.65 0.65 0.65], ...
                 'LineWidth', 0.6, ...
                 'HandleVisibility', 'off');
        end
    end

    % Fitted deterministic mean curve.
    hMean = plot(tfine, mu_fine, 'r-', ...
                 'LineWidth', 2.4, ...
                 'DisplayName', 'Fitted mean');

    % Observed daily confirmed counts.
    hData = plot(t, y, 'ko', ...
                 'MarkerFaceColor', 'k', ...
                 'MarkerSize', 6.5, ...
                 'DisplayName', 'Observed data');

    xlabel('Date', 'FontSize', 12);
    ylabel('Daily confirmed cases', 'FontSize', 12);

    grid on;
    box on;

    ax = gca;
    ax.FontSize = 11;
    ax.LineWidth = 1;
    ax.TickDir = 'out';

    xticks(t);
    xticklabels(dateLabels);
    xtickangle(30);
    xlim([min(t) - 0.15, max(t) + 0.15]);

    ymax = max([y(:); mu_fine(:); pred_high(:); pred_show(:)]);
    ylim([0, 1.08 * ymax]);

    % Manual legend. We avoid calling MATLAB's legend() function because
    % some installations or paths may treat legend.m as a script.
    add_manual_legend_fig3_local(t, ymax);

    %% ================================================================
    %  Appendix figure: Profile likelihood for E(K)
    %  ================================================================

    dev = results.profile_deviance;
    EK = results.profile_table.EK;
    cutoff = results.profile_cutoff_dev;
    EKhat = results.EK_hat;
    EKci = results.EK_CI_profile;

    figure('Name', 'Profile likelihood for E(K)', 'Color', 'w');
    hold on;

    plot(EK, dev, 'b-', 'LineWidth', 2.0);
    yline(cutoff, 'r--', '95% cutoff', 'LineWidth', 1.5);
    xline(EKhat, 'k--', 'MLE', 'LineWidth', 1.2);

    if all(isfinite(EKci))
        xline(EKci(1), ':', ...
              'Color', [0.35 0.35 0.35], ...
              'LineWidth', 1.1);
        xline(EKci(2), ':', ...
              'Color', [0.35 0.35 0.35], ...
              'LineWidth', 1.1);
    end

    xlabel('E(K)', 'FontSize', 12);
    ylabel('Profile deviance', 'FontSize', 12);

    grid on;
    box on;

    ax2 = gca;
    ax2.FontSize = 11;
    ax2.LineWidth = 1;
    ax2.TickDir = 'out';

    ylim([0, results.pars.profile_ylim]);

    if all(isfinite(EKci))
        xlo = max(results.pars.EK_lb, EKci(1) - results.pars.profile_xpad);
        xhi = min(results.pars.EK_ub, EKci(2) + results.pars.profile_xpad);
        xlim([xlo, xhi]);
    else
        xlim([results.pars.EK_lb, results.pars.EK_ub]);
    end
end

% =======================================================================
% Manual legend for Fig. 3
% =======================================================================

function add_manual_legend_fig3_local(t, ymax)
%ADD_MANUAL_LEGEND_FIG3_LOCAL
% Draw a simple manual legend inside the current axes.
% This avoids calling MATLAB's legend() function, which caused an error
% on some MATLAB installations.

    if ymax <= 0 || ~isfinite(ymax)
        ymax = 1;
    end

    x0 = min(t) + 0.10;
    x1 = x0 + 0.38;
    xt = x1 + 0.12;

    y0 = 0.92 * ymax;
    dy = 0.075 * ymax;
    boxH = 0.025 * ymax;

    fs = 9;

    % 95% predictive interval
    patch([x0 x1 x1 x0], ...
          [y0 - boxH, y0 - boxH, y0 + boxH, y0 + boxH], ...
          [0.85 0.85 0.85], ...
          'EdgeColor', 'none', ...
          'FaceAlpha', 0.65, ...
          'HandleVisibility', 'off');
    text(xt, y0, '95% predictive interval', ...
         'FontSize', fs, ...
         'VerticalAlignment', 'middle', ...
         'Interpreter', 'none');

    % Stochastic predictive trajectories
    y1 = y0 - dy;
    plot([x0 x1], [y1 y1], '-', ...
         'Color', [0.65 0.65 0.65], ...
         'LineWidth', 1.0, ...
         'HandleVisibility', 'off');
    text(xt, y1, 'Predictive trajectories', ...
         'FontSize', fs, ...
         'VerticalAlignment', 'middle', ...
         'Interpreter', 'none');

    % Fitted mean
    y2 = y0 - 2 * dy;
    plot([x0 x1], [y2 y2], 'r-', ...
         'LineWidth', 2.0, ...
         'HandleVisibility', 'off');
    text(xt, y2, 'Fitted mean', ...
         'FontSize', fs, ...
         'VerticalAlignment', 'middle', ...
         'Interpreter', 'none');

    % Observed data
    y3 = y0 - 3 * dy;
    plot(mean([x0 x1]), y3, 'ko', ...
         'MarkerFaceColor', 'k', ...
         'MarkerSize', 5.5, ...
         'HandleVisibility', 'off');
    text(xt, y3, 'Observed data', ...
         'FontSize', fs, ...
         'VerticalAlignment', 'middle', ...
         'Interpreter', 'none');
end

% =======================================================================
% Safe trapz
% =======================================================================

function val = trapz_safe_local(x, y)
    x = x(:);
    y = y(:);
    if numel(x) <= 1 || numel(y) <= 1
        val = 0;
    else
        val = trapz(x, y);
    end
end