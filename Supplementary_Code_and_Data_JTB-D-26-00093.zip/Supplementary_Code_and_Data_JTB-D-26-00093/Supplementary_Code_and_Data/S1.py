"""
Step 1: Data cleaning and first-round infection time estimation.
Excludes cases with route = 'Asymptomatic active screening'.
"""

import pandas as pd
import numpy as np
import re
import os
from scipy.stats import weibull_min, expon, uniform
import warnings
warnings.filterwarnings('ignore')

INCUBATION_SHAPE = 1.83
INCUBATION_SCALE = 4.93
incubation_dist = weibull_min(c=INCUBATION_SHAPE, scale=INCUBATION_SCALE)
Q95_INCUBATION = incubation_dist.ppf(0.95)

def load_and_clean_data(filepath):
    """Load raw data, filter out asymptomatic screening cases, parse dates, and prepare columns."""
    df = pd.read_csv(filepath, encoding='utf-8-sig')

    if 'route' in df.columns:
        initial = len(df)
        df = df[df['route'] != 'asymptomatic']
        print(f"Removed asymptomatic active screening: {initial - len(df)} records, {len(df)} remaining")

    df['quarantine date'] = pd.to_datetime(df['quarantine date'], errors='coerce')
    df['confirmation date'] = pd.to_datetime(df['confirmation date'], errors='coerce')
    df['symptom onset date'] = pd.to_datetime(df['symptom onset date'], errors='coerce')

    df['C_date'] = df['quarantine date'].fillna(df['confirmation date'])
    df['O_date'] = df['symptom onset date']

    def clean_parent_id(val):
        if pd.isna(val):
            return 0
        val_str = str(val).strip()
        if any(sep in val_str for sep in ['、', ',', '，', ' ']):
            numbers = re.findall(r'\d+', val_str)
            return int(numbers[0]) if numbers else 0
        try:
            return int(float(val_str))
        except ValueError:
            return 0

    df['parent_id'] = df['parent_id'].apply(clean_parent_id)

    def classify_route(route):
        if pd.isna(route):
            return 'other'
        route = str(route).strip().lower()
        if route == 'diagnosis':
            return 'diagnosis'
        elif route == 'screening':
            return 'screening'
        elif route == 'tracing':
            return 'tracing'
        else:
            return 'other'

    df['route3'] = df['route'].apply(classify_route)

    children = {cid: [] for cid in df['case_id']}
    for _, row in df.iterrows():
        pid = row['parent_id']
        if pid != 0 and pid in children:
            children[pid].append(row['case_id'])
    df['children'] = df['case_id'].map(children)

    t0 = pd.Timestamp('2021-07-20')
    df['C_num'] = (df['C_date'] - t0).dt.total_seconds() / 86400.0
    df['O_num'] = (df['O_date'] - t0).dt.total_seconds() / 86400.0
    df['has_onset'] = df['symptom onset date'].notna()

    initial_len = len(df)
    df = df.dropna(subset=['C_num'])
    print(f"Removed missing C_date: {initial_len - len(df)} records, {len(df)} remaining")

    earliest_onset = df.loc[df['has_onset'], 'O_num'].min() if df['has_onset'].any() else df['C_num'].min() - 5.0
    return df, t0, earliest_onset

def reconstruct_infection_times(df, beta_hat=None, use_exp_prior=False,
                                warn_counts=None, t_intro=None,
                                delta=0.5, R=7.0, gamma=0.20):
    """Reconstruct infection times for one MCMC iteration."""
    if warn_counts is None:
        warn_counts = {'onset_failed': 0, 'invalid_interval': 0, 'exp_failed': 0}

    T_dict = {}
    processed = set()

    def process_case(cid):
        if cid in processed:
            return
        row = df[df['case_id'] == cid].iloc[0]
        parent_id = row['parent_id']
        if parent_id != 0 and parent_id not in processed:
            process_case(parent_id)

        C_i = row['C_num']
        has_onset = row['has_onset']
        O_i = row['O_num'] if has_onset else None

        if has_onset:
            max_attempts = 1000
            attempts = 0
            success = False
            while attempts < max_attempts:
                L = incubation_dist.rvs()
                T_cand = O_i - L
                if T_cand > t_intro and T_cand <= C_i:
                    if parent_id != 0:
                        T_parent = T_dict[parent_id]
                        if T_cand >= T_parent + delta:
                            T_dict[cid] = T_cand
                            success = True
                            break
                    else:
                        T_dict[cid] = T_cand
                        success = True
                        break
                attempts += 1
            if not success:
                warn_counts['onset_failed'] += 1
                T_dict[cid] = C_i - delta
        else:
            if parent_id == 0:
                low = max(t_intro, C_i - R)
                high = C_i - delta
            else:
                T_parent = T_dict[parent_id]
                low = T_parent + delta
                high = C_i

            if low >= high:
                warn_counts['invalid_interval'] += 1
                T_dict[cid] = high - 0.01
            else:
                if use_exp_prior and beta_hat is not None and parent_id != 0:
                    rate = beta_hat + gamma
                    max_attempts = 1000
                    attempts = 0
                    success = False
                    while attempts < max_attempts:
                        X = expon.rvs(scale=1/rate)
                        T_cand = T_parent + X
                        if low <= T_cand <= high:
                            T_dict[cid] = T_cand
                            success = True
                            break
                        attempts += 1
                    if not success:
                        warn_counts['exp_failed'] += 1
                        T_dict[cid] = uniform.rvs(loc=low, scale=high-low)
                else:
                    T_dict[cid] = uniform.rvs(loc=low, scale=high-low)
        processed.add(cid)

    roots = df[df['parent_id'] == 0]['case_id'].tolist()
    non_roots = df[df['parent_id'] != 0]['case_id'].tolist()
    for cid in roots + non_roots:
        process_case(cid)
    return T_dict, warn_counts

def estimate_beta(df, T_dict, gamma=0.10):
    """Estimate transmission rate beta from serial intervals."""
    deltas = []
    for _, row in df.iterrows():
        pid = row['parent_id']
        if pid != 0:
            deltas.append(T_dict[row['case_id']] - T_dict[pid])
    if not deltas:
        return np.nan
    mean_delta = np.mean(deltas)
    return max(0, 1/mean_delta - gamma)

def get_first_round_infection_times(df, earliest_onset, M=500, n_iter=3,
                                    delta=0.5, R=7.0, gamma=0.20):
    """Run multiple MCMC chains and return mean infection times."""
    t_intro = earliest_onset - Q95_INCUBATION
    all_T = {cid: [] for cid in df['case_id']}

    print(f"Running first-round infection time estimation (M={M})...")
    for m in range(M):
        if (m+1) % 10 == 0:
            print(f"  Progress {m+1}/{M}")
        warn_counts = {'onset_failed': 0, 'invalid_interval': 0, 'exp_failed': 0}
        T_dict, _ = reconstruct_infection_times(
            df, beta_hat=None, use_exp_prior=False, warn_counts=warn_counts,
            t_intro=t_intro, delta=delta, R=R, gamma=gamma
        )
        beta_hat = estimate_beta(df, T_dict, gamma)
        for _ in range(1, n_iter):
            T_dict, _ = reconstruct_infection_times(
                df, beta_hat=beta_hat, use_exp_prior=True, warn_counts=warn_counts,
                t_intro=t_intro, delta=delta, R=R, gamma=gamma
            )
            beta_hat = estimate_beta(df, T_dict, gamma)
        for cid in df['case_id']:
            all_T[cid].append(T_dict[cid])

    df_result = df.copy()
    df_result['T_round1'] = df_result['case_id'].map(lambda cid: np.mean(all_T[cid]))
    return df_result

if __name__ == "__main__":
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    input_path = os.path.join(data_dir, "cases_raw.csv")
    output_path = os.path.join(data_dir, "cases_T1.csv")

    print("=" * 60)
    print("Step 1: Data loading and first-round infection time calculation")
    print("=" * 60)
    df, t0, earliest_onset = load_and_clean_data(input_path)
    print(f"Valid cases: {len(df)}")

    df = get_first_round_infection_times(df, earliest_onset, M=500, n_iter=3)
    df.to_csv(output_path, index=False, encoding='utf-8-sig')
    print(f"\nResults saved to: {output_path}")