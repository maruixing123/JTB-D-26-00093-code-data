"""
S2_tree_complete.py (English dataset, CSV format)
Deterministic completion of transmission tree.
Overwrites 'parent_id' column with completed parent assignments.
Output tree_full.csv contains only: case_id, age, parent_id, C_num, O_num, has_onset.
"""

import pandas as pd
import numpy as np
import re
import os
import warnings
warnings.filterwarnings('ignore')

# ==================== Configuration ====================
DELTA = 0.5                      # minimum serial interval (days)
T0 = pd.Timestamp('2021-07-20')  # reference date (same as S1)
TOTAL_ROOT = 1                   # root case ID

USE_ID_DIFF_CONSTRAINT = True
ID_DIFF_PERCENTILE = 50
ID_DIFF_MIN = 20
ID_DIFF_MAX_CAP = 300

# ---------- Column names (English) ----------
COL_CASE_ID = 'case_id'
COL_PARENT = 'parent_id'                # will be overwritten with completed parent
COL_ISOLATION = 'quarantine date'
COL_CONFIRM = 'confirmation date'
COL_SYMPTOM = 'symptom onset date'
COL_T_ROUND1 = 'T_round1'
COL_HAS_ONSET = 'has_onset'
COL_O_DATE = 'O_date'
COL_C_NUM = 'C_num'
COL_O_NUM = 'O_num'

COL_ADDRESS = 'Address'
COL_AREA = 'district'
COL_PLACE = 'associated_place'

# ==================== Helper functions ====================
def clean_parent_id(val):
    """Extract first number from parent_id field (handles Chinese separators)."""
    if pd.isna(val):
        return 0
    val_str = str(val).strip()
    if any(sep in val_str for sep in ['、', ',', '，', ' ']):
        numbers = re.findall(r'\d+', val_str)
        return int(numbers[0]) if numbers else 0
    try:
        return int(float(val_str))
    except ValueError:
        return 0

def is_descendant(df, ancestor, descendant, parent_col=COL_PARENT):
    """Check if ancestor is on the known parent path of descendant."""
    current = descendant
    visited = set()
    while current != 0:
        if current == ancestor:
            return True
        if current in visited:
            break
        visited.add(current)
        row = df[df[COL_CASE_ID] == current]
        if row.empty:
            break
        parent = row.iloc[0][parent_col]
        if parent == 0:
            break
        current = parent
    return False

def get_iso_date(row):
    """Return isolation date; if missing, use confirmation date."""
    iso = row[COL_ISOLATION]
    if pd.isna(iso):
        iso = row[COL_CONFIRM]
    return iso

def compute_median_serial_interval(df):
    """Compute median serial interval from known parent-child pairs (T_round1 diff)."""
    known = df[df[COL_PARENT] != 0]
    if len(known) == 0:
        return 5.0
    deltas = []
    for _, row in known.iterrows():
        child = row[COL_CASE_ID]
        parent = row[COL_PARENT]
        if parent in df[COL_CASE_ID].values:
            T_c = df.loc[df[COL_CASE_ID] == child, COL_T_ROUND1].values[0]
            T_p = df.loc[df[COL_CASE_ID] == parent, COL_T_ROUND1].values[0]
            if T_c > T_p:
                deltas.append(T_c - T_p)
    return np.median(deltas) if deltas else 5.0

def compute_max_id_diff(df, percentile=50, min_threshold=20, max_cap=300):
    """Compute case ID difference threshold from known edges."""
    known_edges = df[df[COL_PARENT] != 0]
    if len(known_edges) == 0:
        return min_threshold
    diffs = [abs(row[COL_CASE_ID] - row[COL_PARENT]) for _, row in known_edges.iterrows()]
    if not diffs:
        return min_threshold
    diffs = np.array(diffs)
    print(f"  ID diff stats: min={diffs.min()}, 25%={np.percentile(diffs,25):.0f}, "
          f"50%={np.percentile(diffs,50):.0f}, 75%={np.percentile(diffs,75):.0f}, "
          f"90%={np.percentile(diffs,90):.0f}, 95%={np.percentile(diffs,95):.0f}, max={diffs.max()}")
    p_val = np.percentile(diffs, percentile)
    threshold = int(np.clip(p_val, min_threshold, max_cap))
    print(f"  Using {percentile}% percentile {p_val:.0f}, capped threshold = {threshold}")
    return threshold


def parse_address_depth(addr):
    """
    Parse the depth (number of levels) of a desensitized address separated by '-'.
    Returns the number of levels, or 0 if the address is empty.
    """
    if pd.isna(addr) or str(addr).strip() == '':
        return 0
    parts = str(addr).strip().split('-')
    return len(parts)

def common_prefix_depth(addr1, addr2):
    """
    Compute the length of the longest common prefix between two hierarchical addresses.
    Compares level by level (e.g., city, district, street, block) and returns the number
    of matching levels from the start.
    """
    if pd.isna(addr1) or pd.isna(addr2):
        return 0
    parts1 = str(addr1).strip().split('-')
    parts2 = str(addr2).strip().split('-')
    depth = 0
    for p1, p2 in zip(parts1, parts2):
        if p1 == p2:
            depth += 1
        else:
            break
    return depth

# ==================== Modified get_auto_level  ====================
def get_auto_level(row_i, row_j, traj_level_dict=None):
    """
    Determine the automatic connection level for a candidate pair.
    Priority order (highest to lowest):
    1. Trajectory contact level (if exists and is A/B/C)
    2. Address common prefix depth (depth >= 4 -> A, depth == 3 -> B, depth == 2 -> C, otherwise -> D)
    3. Associated place exactly equal -> B
    4. District equal -> C
    5. Default -> D
    """
    # ---------- Priority 1: Trajectory contact level ----------
    if traj_level_dict is not None:
        pair = tuple(sorted([row_i[COL_CASE_ID], row_j[COL_CASE_ID]]))
        if pair in traj_level_dict:
            traj_level = traj_level_dict[pair]
            if traj_level in ['A', 'B', 'C']:
                return traj_level

    addr_i = str(row_i[COL_ADDRESS]) if pd.notna(row_i[COL_ADDRESS]) else ''
    addr_j = str(row_j[COL_ADDRESS]) if pd.notna(row_j[COL_ADDRESS]) else ''

    # ---------- Priority 2: Address matching based on common prefix depth ----------
    if addr_i != '' and addr_j != '':
        depth = common_prefix_depth(addr_i, addr_j)
        if depth >= 4:          # Match down to block level (equivalent to original exact match)
            return 'A'
        elif depth == 3:        # Match down to street level (equivalent to original partial inclusion)
            return 'B'
        elif depth == 2:        # Match down to district level
            return 'C'
        else:                   # Only city matches or no common prefix
            return 'D'

    # ---------- Priority 3: Associated place exactly equal ----------
    place_i = str(row_i[COL_PLACE]) if pd.notna(row_i[COL_PLACE]) else ''
    place_j = str(row_j[COL_PLACE]) if pd.notna(row_j[COL_PLACE]) else ''
    if place_i != '' and place_j != '' and place_i == place_j:
        return 'B'   # Consistent with original logic

    # ---------- Priority 4: District equal ----------
    area_i = str(row_i[COL_AREA]) if pd.notna(row_i[COL_AREA]) else ''
    area_j = str(row_j[COL_AREA]) if pd.notna(row_j[COL_AREA]) else ''
    if area_i != '' and area_j != '' and area_i == area_j:
        return 'C'

    # ---------- Default: no match ----------
    return 'D'

def generate_candidate_pool(df, total_root, traj_level_dict=None, delta=DELTA, max_id_diff=None):
    """Generate candidate pool and keep only highest level per case."""
    pending = df[(df[COL_PARENT] == 0) & (df[COL_CASE_ID] != total_root)][COL_CASE_ID].tolist()
    print(f"Pending cases: {len(pending)}")
    if len(pending) == 0:
        return pd.DataFrame()

    rows = []
    t0_date = T0
    for i in pending:
        row_i = df[df[COL_CASE_ID] == i].iloc[0]
        T_i = row_i[COL_T_ROUND1]
        T_i_date = t0_date + pd.Timedelta(days=T_i)

        for _, row_j in df.iterrows():
            j = row_j[COL_CASE_ID]
            if j == i:
                continue
            T_j = row_j[COL_T_ROUND1]
            if T_j + delta > T_i:
                continue
            if max_id_diff is not None and abs(i - j) > max_id_diff:
                continue
            iso_date_j = get_iso_date(row_j)
            if pd.isna(iso_date_j) or iso_date_j <= T_i_date:
                continue
            if is_descendant(df, j, i, parent_col=COL_PARENT):
                continue

            auto_level = get_auto_level(row_i, row_j, traj_level_dict)

            Delta = T_i - T_j
            rows.append({
                'case_i': i,
                'candidate_j': j,
                'T_i': round(T_i, 3),
                'T_j': round(T_j, 3),
                'Delta': round(Delta, 3),
                'isolation_j': row_j[COL_ISOLATION],
                'confirmation_j': row_j[COL_CONFIRM],
                'has_onset_j': row_j[COL_HAS_ONSET],
                'onset_j': row_j[COL_O_DATE] if row_j[COL_HAS_ONSET] else None,
                'address_i': row_i[COL_ADDRESS] if pd.notna(row_i[COL_ADDRESS]) else '',
                'address_j': row_j[COL_ADDRESS] if pd.notna(row_j[COL_ADDRESS]) else '',
                'district_i': row_i[COL_AREA] if pd.notna(row_i[COL_AREA]) else '',
                'district_j': row_j[COL_AREA] if pd.notna(row_j[COL_AREA]) else '',
                'place_i': row_i[COL_PLACE] if pd.notna(row_i[COL_PLACE]) else '',
                'place_j': row_j[COL_PLACE] if pd.notna(row_j[COL_PLACE]) else '',
                'parent_id_j': row_j[COL_PARENT],
                'auto_level': auto_level,
                'manual_level': '',
                'manual_select': ''
            })

    df_pool = pd.DataFrame(rows)
    print(f"Initial pool size: {len(df_pool)}")

    if not df_pool.empty:
        level_order = {'A': 0, 'B': 1, 'C': 2, 'D': 3}
        df_pool['_level_num'] = df_pool['auto_level'].map(level_order)

        def filter_group(group):
            min_level = group['_level_num'].min()
            return group[group['_level_num'] == min_level]

        df_pool = df_pool.groupby('case_i', group_keys=False).apply(filter_group)
        df_pool.drop('_level_num', axis=1, inplace=True)
        print(f"After keeping only highest level: {len(df_pool)}")

    if not df_pool.empty:
        print("Auto level distribution:")
        print(df_pool['auto_level'].value_counts().to_string())
    return df_pool

def rank_candidates(df_pool, m_G=5.0):
    """Rank candidates within same level; penalize candidates that are themselves pending."""
    if df_pool.empty:
        return df_pool

    df_pool = df_pool.copy()
    df_pool['Abs_Diff'] = abs(df_pool['Delta'] - m_G)
    df_pool['_iso_ts'] = pd.to_datetime(df_pool['isolation_j']).astype('int64')
    df_pool['is_pending_j'] = (df_pool['parent_id_j'] == 0)

    sort_keys = ['Abs_Diff', 'is_pending_j', '_iso_ts', 'has_onset_j', 'onset_j', 'candidate_j']
    ascending = [True, True, False, False, True, True]

    df_pool = df_pool.sort_values(by=sort_keys, ascending=ascending, na_position='last')
    df_pool['rank'] = df_pool.groupby('case_i').cumcount() + 1
    df_pool['preferred'] = df_pool['rank'].apply(lambda x: '★' if x == 1 else '')

    drop_cols = ['Abs_Diff', '_iso_ts', 'is_pending_j']
    df_pool.drop([col for col in drop_cols if col in df_pool.columns], axis=1, inplace=True)
    return df_pool

def apply_auto_selection(df_original, df_pool, total_root):
    """Assign parent_id based on top-ranked candidate (overwrites original parent_id)."""
    df_complete = df_original.copy()

    if 'edge_confidence' not in df_complete.columns:
        df_complete['edge_confidence'] = ''

    if df_pool.empty:
        return df_complete

    for case in df_pool['case_i'].unique():
        top = df_pool[(df_pool['case_i'] == case) & (df_pool['rank'] == 1)]
        if not top.empty:
            row = top.iloc[0]
            df_complete.loc[df_complete[COL_CASE_ID] == case, COL_PARENT] = row['candidate_j']
            df_complete.loc[df_complete[COL_CASE_ID] == case, 'edge_confidence'] = row['auto_level']

    df_complete.loc[df_complete[COL_CASE_ID] == total_root, COL_PARENT] = 0
    return df_complete

def find_descendants(df, root_cases, parent_col=COL_PARENT):
    """Recursively find all descendants."""
    children_map = {cid: [] for cid in df[COL_CASE_ID]}
    for _, row in df.iterrows():
        parent = row[parent_col]
        if parent != 0 and parent in children_map:
            children_map[parent].append(row[COL_CASE_ID])
    result = {}
    for root in root_cases:
        descendants = []
        queue = [root]
        while queue:
            current = queue.pop(0)
            for child in children_map.get(current, []):
                if child not in descendants:
                    descendants.append(child)
                    queue.append(child)
        result[root] = descendants
    return result

def report_incomplete_chains(df, total_root=1, parent_col=COL_PARENT):
    """Report cases still missing a parent."""
    broken_roots = df[(df[COL_CASE_ID] != total_root) & (df[parent_col] == 0)][COL_CASE_ID].tolist()
    if not broken_roots:
        print("All non-root cases have a parent assigned.")
        return
    print(f"\nFound {len(broken_roots)} incomplete root(s).")
    descendants_dict = find_descendants(df, broken_roots, parent_col)
    total_descendants = 0
    for root in broken_roots:
        desc = descendants_dict[root]
        total_descendants += len(desc)
        print(f"  Broken root {root}: {len(desc)} descendants")
    print(f"Total affected cases: {len(broken_roots) + total_descendants}")
    return broken_roots, descendants_dict

# ==================== Main ====================
if __name__ == "__main__":
    # File paths (CSV format)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    input_path = os.path.join(data_dir, "cases_T1.csv")
    traj_file = os.path.join(data_dir, "traj_raw.csv")
    output_tree = os.path.join(data_dir, "tree_full.csv")
    output_pool = os.path.join(data_dir, "candidates.csv")

    # 1. Load trajectory level dictionary
    traj_level_dict = {}
    if os.path.exists(traj_file):
        print("Loading trajectory contact levels...")
        df_traj = pd.read_csv(traj_file, encoding='utf-8-sig')
        if 'case_i' not in df_traj.columns or 'case_j' not in df_traj.columns:
            raise KeyError("Trajectory file must contain 'case_i' and 'case_j' columns.")
        level_col = 'Trajectory Level'
        if level_col not in df_traj.columns:
            raise KeyError(f"Trajectory file missing '{level_col}' column.")
        print(f"Using level column: '{level_col}'")
        df_traj['case_i'] = df_traj['case_i'].astype(int)
        df_traj['case_j'] = df_traj['case_j'].astype(int)
        for _, row in df_traj.iterrows():
            pair = tuple(sorted([row['case_i'], row['case_j']]))
            traj_level_dict[pair] = row[level_col]
        print(f"Loaded {len(traj_level_dict)} trajectory pairs.")
    else:
        print("Warning: Trajectory file not found. Using only basic fields for level.")

    # 2. Read base data
    print("\nReading base data...")
    df = pd.read_csv(input_path, encoding='utf-8-sig')
    for col in [COL_ISOLATION, COL_CONFIRM, COL_SYMPTOM]:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors='coerce')

    # Ensure parent_id column exists and is cleaned
    if COL_PARENT not in df.columns:
        print("Warning: 'parent_id' column missing. Creating from scratch.")
        df[COL_PARENT] = 0
    else:
        df[COL_PARENT] = df[COL_PARENT].apply(clean_parent_id).fillna(0).astype(int)

    # Add C_num and O_num if not already present (they should be from S1)
    if COL_C_NUM not in df.columns or COL_O_NUM not in df.columns:
        # Compute from dates as fallback
        t0 = T0
        df['C_date'] = df[COL_ISOLATION].fillna(df[COL_CONFIRM])
        df['O_date'] = df[COL_SYMPTOM]
        df[COL_C_NUM] = (df['C_date'] - t0).dt.days
        df[COL_O_NUM] = (df['O_date'] - t0).dt.days
        df[COL_HAS_ONSET] = df['O_date'].notna()
    else:
        # Ensure has_onset is consistent
        if COL_HAS_ONSET not in df.columns:
            df[COL_HAS_ONSET] = df[COL_SYMPTOM].notna()

    total_root = TOTAL_ROOT
    if total_root not in df[COL_CASE_ID].values:
        raise ValueError(f"Total root case {total_root} not found in data!")
    print(f"Total root case: {total_root}")

    # 3. Compute auxiliary parameters
    m_G = compute_median_serial_interval(df)
    print(f"Median serial interval: {m_G:.2f} days")

    max_id_diff = None
    if USE_ID_DIFF_CONSTRAINT:
        print("\nComputing case ID difference constraint...")
        max_id_diff = compute_max_id_diff(df, percentile=ID_DIFF_PERCENTILE,
                                          min_threshold=ID_DIFF_MIN, max_cap=ID_DIFF_MAX_CAP)
    else:
        print("\nCase ID difference constraint disabled.")

    # 4. Generate candidate pool
    print("\nGenerating candidate pool...")
    df_pool = generate_candidate_pool(df, total_root, traj_level_dict, delta=DELTA, max_id_diff=max_id_diff)

    if df_pool.empty:
        print("No pending cases. Exiting.")
        # Still save output with required columns
        keep_cols = ['case_id', 'age', 'parent_id', 'C_num', 'O_num', 'has_onset']
        available_cols = [col for col in keep_cols if col in df.columns]
        df_out = df[available_cols].copy()
        df_out.to_csv(output_tree, index=False, encoding='utf-8-sig')
        print(f"Tree saved to: {output_tree}")
        exit()

    # 5. Rank candidates
    df_pool = rank_candidates(df_pool, m_G=m_G)

    print("Ranking completed.")

    # 6. Auto-assign parents (overwrites parent_id)
    print("\nAssigning parents automatically (top-ranked candidate)...")
    df_complete = apply_auto_selection(df, df_pool, total_root)


    # 7. Save results (only required columns in tree_full.csv)
    keep_cols = ['case_id', 'age', 'parent_id', 'C_num', 'O_num', 'has_onset']
    available_cols = [col for col in keep_cols if col in df_complete.columns]
    df_tree_out = df_complete[available_cols].copy()

    df_pool.to_csv(output_pool, index=False, encoding='utf-8-sig')
    df_tree_out.to_csv(output_tree, index=False, encoding='utf-8-sig')
    print(f"\nCandidate pool saved to: {output_pool}")
    print(f"Complete tree saved to: {output_tree}")

    # 8. Final verification
    final_zeros = (df_complete[COL_PARENT] == 0).sum()
    print(f"\nFinal number of cases with parent_id=0: {final_zeros} (should be exactly 1, the total root)")

    print("\n" + "=" * 60)
    print("Checking incomplete chains after auto-assignment:")
    report_incomplete_chains(df_complete, total_root=TOTAL_ROOT, parent_col=COL_PARENT)