"""
S4_plot_sensitivity.py (standalone plotting script)
Reads mu_d and sigma_d samples from CSV files and generates h_d(τ) sensitivity plots.
Main curve: using median of mu_d and sigma_d (fixed parameter curve).
Confidence band: pointwise 2.5%~97.5% quantiles from all samples.
Output: PDF files.
"""

import pandas as pd
import numpy as np
import os
from scipy.stats import lognorm
import matplotlib.pyplot as plt

def plot_hd_curve_from_samples(mu_samples, sigma_samples, tau_max=20,
                               label=None, color=None, ax=None, alpha_ci=0.1,
                               show_ci_legend=False):
    """
    Plot h_d(τ) curve with 95% pointwise confidence band.
    Main curve is calculated from median mu and sigma.
    If show_ci_legend is True, the fill_between will have a label for legend.
    """
    if ax is None:
        ax = plt.gca()
    tau_grid = np.linspace(0.1, tau_max, 200)
    all_curves = []
    for mu, sigma in zip(mu_samples, sigma_samples):
        scale = np.exp(mu)
        pdf = lognorm.pdf(tau_grid, s=sigma, scale=scale)
        cdf = lognorm.cdf(tau_grid, s=sigma, scale=scale)
        h = pdf / (1 - cdf)
        all_curves.append(h)
    all_curves = np.array(all_curves)

    # Pointwise 95% confidence band
    lower_curve = np.percentile(all_curves, 2.5, axis=0)
    upper_curve = np.percentile(all_curves, 97.5, axis=0)
    ci_label = '95% CI' if show_ci_legend else '_nolegend_'
    ax.fill_between(tau_grid, lower_curve, upper_curve,
                    color=color, alpha=alpha_ci, label=ci_label)

    # Main curve: use median of mu and sigma (fixed parameter curve)
    mu_med = np.median(mu_samples)
    sigma_med = np.median(sigma_samples)
    scale_med = np.exp(mu_med)
    pdf_med = lognorm.pdf(tau_grid, s=sigma_med, scale=scale_med)
    cdf_med = lognorm.cdf(tau_grid, s=sigma_med, scale=scale_med)
    h_med = pdf_med / (1 - cdf_med)
    ax.plot(tau_grid, h_med, color=color, linewidth=2, label=label)

    ax.set_xlabel(r'Time since infection $\tau$ (days)')
    ax.grid(False)
    return ax

def plot_sensitivity_for_param(param_name, param_values, samples_dir, output_path,
                               tau_max=20, colors=None):
    plt.figure(figsize=(8, 5))
    if colors is None:
        colors = plt.cm.tab10(np.linspace(0, 1, len(param_values)))
    ax = plt.gca()
    for val, color in zip(param_values, colors):
        sample_file = os.path.join(samples_dir, f"mu_sigma_samples_{param_name}_{val}.csv")
        if not os.path.exists(sample_file):
            print(f"Warning: {sample_file} not found, skipping.")
            continue
        df = pd.read_csv(sample_file)
        mu_samples = df['mu_d'].values
        sigma_samples = df['sigma_d'].values
        if len(mu_samples) == 0:
            print(f"Warning: No samples in {sample_file}, skipping.")
            continue
        label = f"{param_name} = {val}"
        # For sensitivity plots, do NOT show CI legend
        plot_hd_curve_from_samples(mu_samples, sigma_samples, tau_max=tau_max,
                                   label=label, color=color, ax=ax,
                                   show_ci_legend=False)
    plt.title(f"Sensitivity of $h_d(\\tau)$ to {param_name}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, format='pdf', dpi=150, bbox_inches='tight')
    plt.close()
    print(f"Plot saved to: {output_path}")

if __name__ == "__main__":
    # ========== Adjust paths as needed ==========
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, "data")
    samples_dir = os.path.join(data_dir, "samples")
    out_plot_dir = data_dir

    # Parameter values (must match those used in S4_main.py)
    sens_configs = {
        'W': [3, 5, 7],
        'delta': [0.25, 0.5, 1.0],
        'R': [5, 7, 10, 14]
    }
    # Colors specified by user
    colors = ['#BF1D2D', '#315A89', '#F6944B', '#018A67']

    # Sensitivity plots (no CI legend)
    for param, values in sens_configs.items():
        output_path = os.path.join(out_plot_dir, f"hd_sensitivity_{param}.pdf")
        plot_sensitivity_for_param(param, values, samples_dir, output_path, colors=colors)

    # Final h_d curve (with CI legend)
    main_file = os.path.join(samples_dir, "mu_sigma_samples_main.csv")
    if os.path.exists(main_file):
        df_main = pd.read_csv(main_file)
        mu_main = df_main['mu_d'].values
        sigma_main = df_main['sigma_d'].values
        plt.figure(figsize=(8, 5))
        ax = plt.gca()
        plot_hd_curve_from_samples(mu_main, sigma_main, tau_max=20,
                                   label='$h_d(\\tau)$', color='#EC3232',
                                   ax=ax, show_ci_legend=True)
        plt.title("Final diagnosis hazard curve (with 95% CI)")
        handles, labels = ax.get_legend_handles_labels()
        by_label = dict(zip(labels, handles))
        ax.legend(by_label.values(), by_label.keys())
        plt.tight_layout()
        out_hd_final = os.path.join(out_plot_dir, "hd_final.pdf")
        plt.savefig(out_hd_final, format='pdf', dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Final h_d curve saved to: {out_hd_final}")
    else:
        print("Main sample file not found, skipping final h_d plot.")

    # ========== Compute and save final parameter estimates from results_main.csv ==========
    results_main_file = os.path.join(out_plot_dir, "results_main.csv")
    if os.path.exists(results_main_file):
        df_res = pd.read_csv(results_main_file)
        summary_rows = []
        for param in ['beta', 'g', 'epsilon', 'mu_d', 'sigma_d', 'ks_p']:
            if param in df_res.columns:
                vals = df_res[param].dropna().values
                if len(vals) > 0:
                    median = np.median(vals)
                    ci_lower = np.percentile(vals, 2.5)
                    ci_upper = np.percentile(vals, 97.5)
                    summary_rows.append({
                        'parameter': param,
                        'median': median,
                        'ci_2.5': ci_lower,
                        'ci_97.5': ci_upper
                    })
        if summary_rows:
            summary_df = pd.DataFrame(summary_rows)
            summary_out = os.path.join(out_plot_dir, "final_parameters.csv")
            summary_df.to_csv(summary_out, index=False, encoding='utf-8-sig')
            print(f"Final parameters saved to: {summary_out}")
        else:
            print("No valid parameter columns found in results_main.csv.")
    else:
        print("results_main.csv not found. Cannot compute final parameters.")