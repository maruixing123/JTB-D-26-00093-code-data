clear; clc; close all
fileName = 'tree_age.csv';

% Age groups (you can modify these)
ageEdges  = [0 20 40 60 80 inf];
ageLabels = {'0-19','20-39','40-59','60-79','80+'};

%% =========================
%  1) Read CSV
%% =========================
[~,~,raw] = xlsread(fileName);

header = raw(1,:);
data   = raw(2:end,:);

% Convert header to char cell and trim spaces
for i = 1:length(header)
    if ischar(header{i})
        header{i} = strtrim(header{i});
    end
end

% Find columns (English names)
idCol     = find(strcmpi(header, 'case_id'));
ageCol    = find(strcmpi(header, 'age'));
parentCol = find(strcmpi(header, 'parent_id'));

if isempty(idCol)
    error('Cannot find column: case number');
end
if isempty(ageCol)
    error('Cannot find column: age');
end
if isempty(parentCol)
    error('Cannot find column: parent  number');
end

%% =========================
%  2) Convert columns to numeric
%% =========================
n = size(data,1);

caseID   = nan(n,1);
age      = nan(n,1);
parentID = nan(n,1);

for i = 1:n
    % case ID
    v = data{i,idCol};
    if isnumeric(v)
        caseID(i) = v;
    elseif ischar(v)
        caseID(i) = str2double(v);
    end

    % age
    v = data{i,ageCol};
    if isnumeric(v)
        age(i) = v;
    elseif ischar(v)
        age(i) = str2double(v);
    end

    % parent ID
    v = data{i,parentCol};
    if isnumeric(v)
        parentID(i) = v;
    elseif ischar(v)
        parentID(i) = str2double(v);
    end
end

%% =========================
%  3) Build caseID -> age map
%% =========================
ageMap = containers.Map('KeyType','double','ValueType','double');

for i = 1:n
    if ~isnan(caseID(i)) && ~isnan(age(i))
        ageMap(caseID(i)) = age(i);
    end
end

%% =========================
%  4) Count infector-infectee pairs by age group
%  Row = infector age group
%  Col = infectee age group
%% =========================
K = length(ageLabels);
M = zeros(K, K);

validPairCount = 0;

for i = 1:n
    % Skip root/external source
    if isnan(parentID(i)) || parentID(i) <= 0
        continue
    end

    % Child age must exist
    if isnan(age(i))
        continue
    end

    % Parent age must exist
    if ~isKey(ageMap, parentID(i))
        continue
    end

    parentAge = ageMap(parentID(i));
    childAge  = age(i);

    % Find age-group index
    pGroup = 0;
    cGroup = 0;

    for g = 1:K
        if parentAge >= ageEdges(g) && parentAge < ageEdges(g+1)
            pGroup = g;
        end
        if childAge >= ageEdges(g) && childAge < ageEdges(g+1)
            cGroup = g;
        end
    end

    if pGroup > 0 && cGroup > 0
        M(pGroup, cGroup) = M(pGroup, cGroup) + 1;
        validPairCount = validPairCount + 1;
    end
end

disp('Total valid transmission pairs used in matrix:');
disp(validPairCount);

disp('Contact matrix (rows = infector, cols = infectee):');
disp(M);

%% =========================

%% =========================
fig = figure('Color','w','Position',[100 100 700 600]);

imagesc(M);


yellow_red_cmap = [1.00, 1.00, 0.80;  
                  1.00, 0.94, 0.60;   
                  1.00, 0.80, 0.40;   
                  1.00, 0.60, 0.20;  
                  1.00, 0.40, 0.00;   
                  0.90, 0.20, 0.00;   
                  0.70, 0.00, 0.00];  
colormap(yellow_red_cmap);

colorbar;

axis equal tight

set(gca, ...
    'XTick', 1:K, ...
    'XTickLabel', ageLabels, ...
    'YTick', 1:K, ...
    'YTickLabel', ageLabels, ...
    'FontName', 'Arial', ...       
    'FontSize', 10, ...             
    'FontWeight', 'normal', ...     
    'TickDir', 'out', ...          
    'TickLength', [0.02 0.02], ... 
    'LineWidth', 0.8);            

xlabel('Infectee age group', 'FontName', 'Arial', 'FontSize', 11, 'FontWeight', 'normal');
ylabel('Infector age group', 'FontName', 'Arial', 'FontSize', 11, 'FontWeight', 'normal');


maxVal = max(M(:));
for i = 1:K
    for j = 1:K
        if M(i,j) > 0.45 * maxVal && maxVal > 0
            txtColor = [1 1 1];
        else
            txtColor = [0.1 0.1 0.1];
        end
        
        text(j, i, num2str(M(i,j)), ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'middle', ...
            'FontSize', 10, ...
            'FontWeight', 'normal', ...
            'FontName', 'Arial', ...
            'Color', txtColor);
    end
end

%% =========================
%  6) Save matrix table
%% =========================
Mtable = array2table(M, ...
    'VariableNames', ageLabels, ...
    'RowNames', ageLabels);

try
    writetable(Mtable, 'contact_matrix_counts.csv', 'WriteRowNames', true);
catch
    disp('Could not save table with row names using writetable in this MATLAB version.');
end

%% =========================
%  7) Export figure
%% =========================
set(fig, 'PaperPositionMode', 'auto');

try
    exportgraphics(fig, 'contact_matrix_heatmap.png', 'Resolution', 600);
catch
    try
        print(fig, 'contact_matrix_heatmap', '-dpng', '-r600');
    catch
        saveas(fig, 'contact_matrix_heatmap.png');
    end
end

disp('Done:');
disp('  Figure saved as: contact_matrix_heatmap.png');
disp('  Matrix saved as: contact_matrix_counts.csv');

