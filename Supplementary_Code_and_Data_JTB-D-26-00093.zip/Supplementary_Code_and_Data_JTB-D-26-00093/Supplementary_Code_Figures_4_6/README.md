This repository/dataset accompanies the manuscript “Infection-age structured epidemic model on a contact tree: Assessing non-pharmaceutical interventions” submitted to Journal of Theoretical Biology (JTB-D-26-00093). 

The data and code are provided to support reproducibility of the numerical results reported in the manuscript.

Supplementary MATLAB Code for Figures 4-6

This supplementary code package contains the MATLAB scripts used to generate Figures 4-6 in the manuscript.

## File description

1. scenario\_comparison.m
This script generates Figure 4. It compares the early-phase normalized incidence trajectories under three intervention scenarios: no intervention, diagnosis only, and integrated non-pharmaceutical interventions consisting of diagnosis, mass screening, and contact tracing.
2. meps\_incidence.m
This script generates Figure 5. It evaluates the effect of the mass screening rate m and the tracing coverage epsilon on the early-phase incidence under the integrated intervention strategy. The incidence ratio is computed as

   I\_T = Lambda\_3(T) / Lambda\_3(0) = exp(lambda\_3 T),

   where lambda\_3 is the early exponential growth rate under the integrated intervention strategy.

3. R\_threshold.m
This script generates Figure 6. It computes the effective reproduction number R\_{c,d,m} under the integrated intervention strategy and plots the threshold boundary R\_{c,d,m}=1 in the parameter plane defined by the tracing coverage epsilon and the mass screening rate m.

   ## Software environment

   The codes are written in MATLAB. They were prepared as deterministic numerical scripts for reproducing the figures in the manuscript.

   Required software:
MATLAB R2019b or later is recommended.

   External dependencies:
No external packages are required. The scripts use standard MATLAB numerical and plotting functions.

   ## How to run

4. Unzip the supplementary code package.
5. Open MATLAB.
6. Set the current MATLAB folder to the unzipped directory.
7. Run each script separately from the MATLAB command window:

   scenario\_comparison
meps\_incidence
R\_threshold

   ## Parameter settings

   All baseline parameter values and numerical settings are defined within the scripts. The notation follows the manuscript. In particular, beta denotes the transmission rate, gamma denotes the recovery rate, E(K) denotes the mean degree of the contact network, m denotes the mass screening rate, and epsilon denotes the tracing coverage.

   ## Reproducibility note

   The numerical results are deterministic. No random sampling is used, and therefore no random seed is required.

