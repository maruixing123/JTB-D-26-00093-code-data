function results = R_threshold()
%R_THRESHOLD
% Figure for Section 5.3.3:
% Impact of NPIs and network structure on the effective reproduction number.
%
% Panel (a):
%   Heatmap of R_{c,d,m} in the (epsilon, m) plane
%   under the baseline E(K), with the threshold contour R_{c,d,m}=1.
%
% Panel (b):
%   Threshold curves in the (epsilon, m) plane satisfying R_{c,d,m}=1
%   for several representative values of E(K).
%
% Modified version:
%   - remove the white point in panel (b)
%   - move the panel (b) legend to the lower-left
%
% Compatible with older MATLAB versions. No reliance on legend() in panel (b).

    clc;
    close all;

    %% =========================================================
    % 1) Baseline parameters
    %% =========================================================
    pars = default_pars_local();

    % Representative E(K) values for panel (b)
    EK_list = [5.5, 6.5, pars.EK, 8.0];

    % Grid for panel (a)
    epsGrid = linspace(0.10, 0.90, 25);
    mGrid   = linspace(0.05, 0.80, 25);

    lambdaMat_baseline = nan(length(mGrid), length(epsGrid));
    Rmat_baseline      = nan(length(mGrid), length(epsGrid));

    fprintf('\n============================================================\n');
    fprintf('Computing Fig. 5.3.3: heatmap and threshold curves\n');
    fprintf('Grid size: %d x %d\n', length(mGrid), length(epsGrid));
    fprintf('Baseline E(K) = %.4f\n', pars.EK);
    fprintf('============================================================\n');

    %% =========================================================
    % 2) Panel (a): heatmap under baseline E(K)
    %% =========================================================
    for i = 1:length(mGrid)
        for j = 1:length(epsGrid)
            pars_tmp = pars;
            pars_tmp.m   = mGrid(i);
            pars_tmp.eps = epsGrid(j);

            [lambda_tmp, R_tmp] = solve_lambda_and_R_integrated_local(pars_tmp);

            lambdaMat_baseline(i,j) = lambda_tmp;
            Rmat_baseline(i,j)      = R_tmp;
        end
    end

    % baseline point
    [lambda_base, R_base] = solve_lambda_and_R_integrated_local(pars);

    fprintf('\nBaseline point:\n');
    fprintf('  epsilon = %.4f\n', pars.eps);
    fprintf('  m       = %.4f\n', pars.m);
    fprintf('  lambda3 = %.6f\n', lambda_base);
    fprintf('  R_c,d,m = %.6f\n', R_base);

    %% =========================================================
    % 3) Panel (b): threshold curves R_{c,d,m}=1 for different E(K)
    %% =========================================================
    epsFine = linspace(0.10, 0.90, 121);
    m_threshold_mat = nan(length(epsFine), length(EK_list));

    fprintf('\nThreshold curves for representative E(K):\n');
    for k = 1:length(EK_list)
        fprintf('  Computing E(K) = %.4f ...\n', EK_list(k));

        for j = 1:length(epsFine)
            eps_val = epsFine(j);

            m_star = solve_m_threshold_local(eps_val, EK_list(k), pars, ...
                min(mGrid), max(mGrid));

            m_threshold_mat(j,k) = m_star;
        end
    end

    %% =========================================================
    % 4) Save baseline table
    %% =========================================================
    [EPS, MM] = meshgrid(epsGrid, mGrid);

    table_baseline = table(EPS(:), MM(:), lambdaMat_baseline(:), Rmat_baseline(:), ...
        'VariableNames', {'epsilon', 'm', 'lambda3', 'Rcdm'});

    %% =========================================================
    % 5) Plot figure
    %% =========================================================
    fig = figure('Color', 'w');
    set(fig, 'Position', [60 60 1400 650]);

    %% -------------------------
    % Panel (a)
    %% -------------------------
    ax1 = subplot(1,2,1);
    hold(ax1, 'on');

    contourf(ax1, epsGrid, mGrid, Rmat_baseline, 16, 'LineColor', 'none');
    colormap(ax1, parula(16));

    % threshold contour R = 1
    [~, hcont] = contour(ax1, epsGrid, mGrid, Rmat_baseline, [1 1], ...
        'k-', 'LineWidth', 2.2);
    hcont.ShowText = 'off';

    cb = colorbar(ax1);
    cb.Label.String = 'R_{c,d,m}';
    cb.Label.FontSize = 11;

    xlabel(ax1, '\epsilon', 'FontSize', 12);
    ylabel(ax1, 'm', 'FontSize', 12);

    xlim(ax1, [min(epsGrid), max(epsGrid)]);
    ylim(ax1, [min(mGrid), max(mGrid)]);

    box(ax1, 'on');
    grid(ax1, 'on');
    ax1.FontSize = 11;
    ax1.LineWidth = 1.0;
    ax1.TickDir = 'out';

    % baseline point (keep only in panel a)
    plot(ax1, pars.eps, pars.m, 'wo', ...
        'MarkerFaceColor', 'w', ...
        'MarkerSize', 7, ...
        'LineWidth', 1.2);

    text(ax1, pars.eps + 0.015, pars.m, 'baseline', ...
        'Color', 'k', 'FontSize', 11, 'FontWeight', 'bold', ...
        'BackgroundColor', 'w', 'Margin', 1.5);

    title(ax1, '(a)', 'FontSize', 16, 'FontWeight', 'normal');

    %% -------------------------
    % Panel (b)
    %% -------------------------
    ax2 = subplot(1,2,2);
    hold(ax2, 'on');

    cols = [ ...
        0.80 0.35 0.10;   % orange-brown
        0.35 0.60 0.90;   % light blue
        0.20 0.60 0.30;   % green
        0.55 0.35 0.75];  % purple

    for k = 1:length(EK_list)
        plot(ax2, epsFine, m_threshold_mat(:,k), '-', ...
            'Color', cols(k,:), 'LineWidth', 2.6);
    end

    % NOTE:
    % The white point in panel (b) has been removed as requested.

    xlabel(ax2, '\epsilon', 'FontSize', 12);
    ylabel(ax2, 'm', 'FontSize', 12);

    xlim(ax2, [0.10, 0.90]);
    ylim(ax2, [0.05, 0.80]);

    box(ax2, 'on');
    grid(ax2, 'on');
    ax2.FontSize = 11;
    ax2.LineWidth = 1.0;
    ax2.TickDir = 'out';

    title(ax2, '(b)', 'FontSize', 16, 'FontWeight', 'normal');

    % manual legend in lower-left
    labels = { ...
        'E(K) = 5.5', ...
        'E(K) = 6.5', ...
        sprintf('E(K) = %.3f (baseline)', pars.EK), ...
        'E(K) = 8.0'};

    draw_manual_legend_threshold_local(ax2, labels, cols);

    %% =========================================================
    % 6) Export
    %% =========================================================
    set(fig, 'PaperPositionMode', 'auto');

    outBase = 'R_threshold_JTB';

    try
        print(fig, [outBase '.png'], '-dpng', '-r600');
    catch
        try
            saveas(fig, [outBase '.png']);
        catch
            warning('PNG file could not be saved automatically.');
        end
    end

    try
        print(fig, [outBase '.eps'], '-depsc2', '-r600');
    catch
        warning('EPS file could not be saved automatically.');
    end

    try
        savefig(fig, [outBase '.fig']);
    catch
        try
            saveas(fig, [outBase '.fig']);
        catch
            warning('FIG file could not be saved automatically.');
        end
    end

    try
        writetable(table_baseline, [outBase '_baseline_heatmap.csv']);
    catch
        warning('CSV file could not be saved automatically.');
    end

    fprintf('\nDone: %s.png / .eps / .fig have been saved.\n', outBase);

    %% =========================================================
    % 7) Return results
    %% =========================================================
    results = struct();
    results.pars               = pars;
    results.EK_list            = EK_list;
    results.epsGrid            = epsGrid;
    results.mGrid              = mGrid;
    results.lambdaMat_baseline = lambdaMat_baseline;
    results.Rmat_baseline      = Rmat_baseline;
    results.lambda_base        = lambda_base;
    results.R_base             = R_base;
    results.epsFine            = epsFine;
    results.m_threshold_mat    = m_threshold_mat;
    results.table_baseline     = table_baseline;
end

%% ========================================================================
% Default parameters
%% ========================================================================

function pars = default_pars_local()
    pars.beta   = 0.2653;
    pars.gamma  = 0.20;
    pars.EK     = 7.0455;
    pars.eps    = 0.5763;
    pars.m      = 0.2684;

    pars.mu_d    = 0.9420281179088986;
    pars.sigma_d = 0.8443162761021743;

    pars.tauMax = 30;
    pars.dt = 0.05;

    pars.lambdaL = -1.5;
    pars.lambdaU =  1.5;
    pars.lambdaExpandStep = 0.5;
    pars.lambdaExpandMax  = 16;

    pars.maxIterHazard = 300;
    pars.tolHazard     = 1e-6;
    pars.relaxHazard   = 0.50;
end

%% ========================================================================
% Solve lambda and R under integrated NPIs
%% ========================================================================

function [lambda3, Rcdm] = solve_lambda_and_R_integrated_local(pars)
    lambda3 = solve_lambda_integrated_local(pars);
    Rcdm    = reproduction_integrated_local(lambda3, pars);
end

function lambda3 = solve_lambda_integrated_local(pars)
    fun = @(lam) lotka_residual_integrated_local(lam, pars);
    lambda3 = solve_scalar_root_local(fun, pars.lambdaL, pars.lambdaU, ...
        pars.lambdaExpandStep, pars.lambdaExpandMax);
end

function val = lotka_residual_integrated_local(lambda, pars)
    [tau, F3] = solve_F3_given_lambda_local(lambda, pars);
    theta = pars.EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-(pars.gamma + lambda) .* tau) .* F3;
    val = trapz(tau, integrand) - 1;
end

function Rcdm = reproduction_integrated_local(lambda, pars)
    [tau, F3] = solve_F3_given_lambda_local(lambda, pars);
    theta = pars.EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-pars.gamma .* tau) .* F3;
    Rcdm = trapz(tau, integrand);
end

%% ========================================================================
% Threshold m for given epsilon and E(K), satisfying R_{c,d,m}=1
%% ========================================================================

function m_star = solve_m_threshold_local(eps_val, EK_val, pars, mL, mU)

    parsL = pars;
    parsL.eps = eps_val;
    parsL.EK  = EK_val;
    parsL.m   = mL;
    RL = solve_R_only_local(parsL);

    parsU = pars;
    parsU.eps = eps_val;
    parsU.EK  = EK_val;
    parsU.m   = mU;
    RU = solve_R_only_local(parsU);

    fL = RL - 1;
    fU = RU - 1;

    % If no threshold exists within [mL, mU], return NaN
    if isnan(fL) || isnan(fU)
        m_star = NaN;
        return;
    end

    if sign(fL) == sign(fU)
        m_star = NaN;
        return;
    end

    obj = @(m) threshold_objective_local(m, eps_val, EK_val, pars);

    opts = optimset('Display', 'off');
    try
        m_star = fzero(obj, [mL, mU], opts);
    catch
        m_star = NaN;
    end
end

function val = threshold_objective_local(m, eps_val, EK_val, pars)
    pars_tmp = pars;
    pars_tmp.m   = m;
    pars_tmp.eps = eps_val;
    pars_tmp.EK  = EK_val;

    Rtmp = solve_R_only_local(pars_tmp);
    val = Rtmp - 1;
end

function Rtmp = solve_R_only_local(pars)
    lambda_tmp = solve_lambda_integrated_local(pars);
    Rtmp = reproduction_integrated_local(lambda_tmp, pars);
end

%% ========================================================================
% Solve F3 for a given lambda
%% ========================================================================

function [tau, F3] = solve_F3_given_lambda_local(lambda, pars)
    tau = (0:pars.dt:pars.tauMax)';
    n = numel(tau);

    beta  = pars.beta;
    epsi  = pars.eps;
    m     = pars.m;
    EK    = pars.EK;
    gamma = pars.gamma;

    hd = diagnosis_hazard_lognormal_local(tau, pars.mu_d, pars.sigma_d);

    z     = EK * (1 - exp(-beta * tau));
    theta = EK * beta * exp(-beta * tau);

    h1 = zeros(n, 1);
    h2 = zeros(n, 1);

    for iter = 1:pars.maxIterHazard
        h1_old = h1;
        h2_old = h2;

        Fd = exp(-cumtrapz(tau, hd));
        Fm = exp(-m * tau);

        Fc1 = exp(-cumtrapz(tau, h1_old));
        Fc2 = exp(-cumtrapz(tau, z .* h2_old));

        F1 = Fc1 .* Fd .* Fm;
        F2 = Fc2 .* Fd .* Fm;

        D1 = trapz(tau, exp(-(lambda + gamma) .* tau) .* theta .* F1);
        D2 = trapz(tau, exp(-(lambda + gamma) .* tau) .* theta .* F2);

        D1 = max(D1, 1e-12);
        D2 = max(D2, 1e-12);

        % update h1
        h1_new = zeros(n, 1);
        Q1 = F1 .* (h1_old + hd + m);

        for i = 1:n
            tau_shift = tau(i:end);
            a = tau_shift - tau(i);

            theta_a = EK * beta * exp(-beta * a);
            integrand = exp(-(lambda + gamma) .* a) .* theta_a .* Q1(i:end);

            h1_new(i) = epsi / D1 * trapz_safe_local(a, integrand);
        end
        h1_new = max(h1_new, 0);

        % update h2
        h2_new = zeros(n, 1);
        R2 = F2 .* (z .* h2_old + hd + m);

        for i = 1:n
            b = tau(1:i);
            theta_b = EK * beta * exp(-beta * b);
            integrand = exp(-(lambda + gamma) .* b) .* theta_b .* flipud(R2(1:i));

            h2_new(i) = epsi / D2 * trapz_safe_local(b, integrand);
        end
        h2_new = max(h2_new, 0);

        % relaxation
        h1 = pars.relaxHazard * h1_old + (1 - pars.relaxHazard) * h1_new;
        h2 = pars.relaxHazard * h2_old + (1 - pars.relaxHazard) * h2_new;

        err = max([norm(h1 - h1_old, inf), norm(h2 - h2_old, inf)]);
        if err < pars.tolHazard
            break;
        end
    end

    hc3 = h1 + z .* h2;

    Fd  = exp(-cumtrapz(tau, hd));
    Fm  = exp(-m * tau);
    Fc3 = exp(-cumtrapz(tau, hc3));

    F3 = Fc3 .* Fd .* Fm;
end

%% ========================================================================
% Diagnosis hazard
%% ========================================================================

function hd = diagnosis_hazard_lognormal_local(tau, mu, sigma)
    tau_safe = max(tau, 1e-12);

    logtau = log(tau_safe);
    pdf = exp(-((logtau - mu).^2) ./ (2 * sigma^2)) ./ ...
        (tau_safe * sigma * sqrt(2*pi));
    cdf = 0.5 * (1 + erf((logtau - mu) ./ (sigma * sqrt(2))));

    S = max(1 - cdf, 1e-12);
    hd = pdf ./ S;
    hd(tau == 0) = 0;
end

%% ========================================================================
% Root solver
%% ========================================================================

function x = solve_scalar_root_local(fun, a, b, expandStep, expandMax)
    fa = fun(a);
    fb = fun(b);

    count = 0;
    while sign(fa) == sign(fb) && count < expandMax
        a = a - expandStep;
        b = b + expandStep;
        fa = fun(a);
        fb = fun(b);
        count = count + 1;
    end

    opts = optimset('Display', 'off');

    if sign(fa) ~= sign(fb)
        x = fzero(fun, [a, b], opts);
    else
        obj = @(z) fun(z).^2;
        x = fminbnd(obj, a, b, opts);
    end
end

%% ========================================================================
% Manual legend for panel (b): lower-left
%% ========================================================================

function draw_manual_legend_threshold_local(ax, labels, cols)

    xl = xlim(ax);
    yl = ylim(ax);

    xr = xl(2) - xl(1);
    yr = yl(2) - yl(1);

    % lower-left legend box region
    x0 = xl(1) + 0.06 * xr;
    x1 = xl(1) + 0.20 * xr;
    tx = xl(1) + 0.24 * xr;

    % from lower-left upward
    yvec = [0.18, 0.30, 0.42, 0.54];
    yvec = yl(1) + yvec * yr;

    for k = 1:length(labels)
        plot(ax, [x0 x1], [yvec(k) yvec(k)], '-', ...
            'Color', cols(k,:), 'LineWidth', 2.6);

        text(ax, tx, yvec(k), labels{k}, ...
            'VerticalAlignment', 'middle', ...
            'FontSize', 10.5, ...
            'Color', 'k');
    end
end

%% ========================================================================
% Safe trapz
%% ========================================================================

function val = trapz_safe_local(x, y)
    x = x(:);
    y = y(:);

    if numel(x) <= 1 || numel(y) <= 1
        val = 0;
    else
        val = trapz(x, y);
    end
end