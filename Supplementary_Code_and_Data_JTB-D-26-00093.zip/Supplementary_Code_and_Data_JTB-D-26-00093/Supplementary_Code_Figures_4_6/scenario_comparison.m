function results = scenario_comparison()
%SCENARIO_COMPARISON
% Compare early-phase incidence trajectories under three scenarios:
%   (1) No intervention
%   (2) Diagnosis only
%   (3) Integrated NPIs: diagnosis + mass screening + full tracing

    clc;
    close all;

    %% =========================================================
    % 1) Baseline parameters
    %% =========================================================
    pars = default_pars_local();

    %% =========================================================
    % 2) No intervention
    %% =========================================================
    lambda0 = pars.beta * (pars.EK - 1) - pars.gamma;
    R0 = pars.beta * pars.EK / (pars.beta + pars.gamma);

    %% =========================================================
    % 3) Diagnosis only
    %% =========================================================
    [lambda_d, tau_d, Fd] = solve_lambda_diagnosis_only_local(pars);

    theta_d = pars.EK * pars.beta * exp(-pars.beta * tau_d);
    Rd = trapz(tau_d, theta_d .* exp(-pars.gamma * tau_d) .* Fd);
    xi_d = Rd / R0;

    %% =========================================================
    % 4) Integrated NPIs
    %% =========================================================
    [lambda3, tau3, F3, h1, h2, h3] = solve_lambda_integrated_local(pars);

    theta3 = pars.EK * pars.beta * exp(-pars.beta * tau3);
    Rcdm = trapz(tau3, theta3 .* exp(-pars.gamma * tau3) .* F3);
    xi_cdm = Rcdm / R0;

    %% =========================================================
    % 5) Normalized incidence trajectories
    %% =========================================================
    tPlot = (0:pars.plot_dt:pars.plot_tEnd)';

    Lambda0_plot = exp(lambda0 * tPlot);
    LambdaD_plot = exp(lambda_d * tPlot);
    Lambda3_plot = exp(lambda3 * tPlot);

    %% =========================================================
    % 6) Print summary
    %% =========================================================
    fprintf('\n============================================================\n');
    fprintf('Scenario comparison under baseline parameters\n');
    fprintf('============================================================\n');
    fprintf('beta    = %.6f\n', pars.beta);
    fprintf('gamma   = %.6f\n', pars.gamma);
    fprintf('EK      = %.6f\n', pars.EK);
    fprintf('eps     = %.6f\n', pars.eps);
    fprintf('m       = %.6f\n', pars.m);
    fprintf('mu_d    = %.6f\n', pars.mu_d);
    fprintf('sigma_d = %.6f\n', pars.sigma_d);
    fprintf('------------------------------------------------------------\n');

    fprintf('No intervention:\n');
    fprintf('  lambda0 = %.6f\n', lambda0);
    fprintf('  R0      = %.6f\n', R0);
    fprintf('------------------------------------------------------------\n');

    fprintf('Diagnosis only:\n');
    fprintf('  lambda_d = %.6f\n', lambda_d);
    fprintf('  Rd       = %.6f\n', Rd);
    fprintf('  1-xi_d   = %.6f\n', 1 - xi_d);
    fprintf('------------------------------------------------------------\n');

    fprintf('Integrated NPIs:\n');
    fprintf('  lambda3        = %.6f\n', lambda3);
    fprintf('  R_c,d,m        = %.6f\n', Rcdm);
    fprintf('  1-xi_c,d,m     = %.6f\n', 1 - xi_cdm);
    fprintf('  xi_d-xi_c,d,m  = %.6f\n', xi_d - xi_cdm);
    fprintf('============================================================\n\n');

    %% =========================================================
    % 7) Tables
    %% =========================================================
    Scenario = {'No intervention'; 'Diagnosis only'; 'Integrated NPIs'};
    GrowthRate_lambda = [lambda0; lambda_d; lambda3];
    ReproductionNumber = [R0; Rd; Rcdm];
    PreventedFraction = [0; 1 - xi_d; 1 - xi_cdm];
    AdditionalPreventedFraction = [NaN; 0; xi_d - xi_cdm];

    summary_table = table(Scenario, GrowthRate_lambda, ReproductionNumber, ...
        PreventedFraction, AdditionalPreventedFraction);

    incidence_table = table(tPlot, Lambda0_plot, LambdaD_plot, Lambda3_plot, ...
        'VariableNames', {'Time', 'NoIntervention', 'DiagnosisOnly', 'IntegratedNPIs'});

    disp(summary_table);

    %% =========================================================
    % 8) Plot figure
    %% =========================================================
    fig = figure('Color', 'w');
    set(fig, 'Position', [100 100 820 560]);

    ax = axes('Parent', fig);
    hold(ax, 'on');

    % paper-friendly colors
    col_orange = [0.85 0.45 0.10];   % No intervention
    col_blue   = [0.45 0.72 0.90];   % Diagnosis only
    col_yellow = [0.85 0.68 0.10];   % Integrated NPIs

    % plot curves
    plot(ax, tPlot, Lambda0_plot, '-', 'Color', col_orange, 'LineWidth', 2.4);
    plot(ax, tPlot, LambdaD_plot, '-', 'Color', col_blue,   'LineWidth', 2.4);
    plot(ax, tPlot, Lambda3_plot, '-', 'Color', col_yellow, 'LineWidth', 2.6);

    set(ax, 'YScale', 'log');

    xlabel(ax, 'Time (days)', 'FontSize', 12);
    ylabel(ax, 'Normalized daily incidence (log scale)', 'FontSize', 12);

    grid(ax, 'on');
    box(ax, 'on');
    ax.FontSize = 11;
    ax.LineWidth = 1.0;
    ax.TickDir = 'out';

    xlim(ax, [0 pars.plot_tEnd]);

    ymin = min([Lambda0_plot; LambdaD_plot; Lambda3_plot]);
    ymax = max([Lambda0_plot; LambdaD_plot; Lambda3_plot]);

    ymin = max(ymin, 1e-8);
    ylim(ax, [ymin, 1.15 * ymax]);

    % manual legend in tighter upper-left position
    draw_manual_legend_local(ax, col_orange, col_blue, col_yellow);

    %% =========================================================
    % 9) Save outputs
    %% =========================================================
    outBase = 'scenario_comparison_JTB';

    try
        print(fig, [outBase '.png'], '-dpng', '-r600');
    catch
        try
            saveas(fig, [outBase '.png']);
        catch
            warning('PNG file could not be saved automatically.');
        end
    end

    try
        print(fig, [outBase '.eps'], '-depsc2', '-r600');
    catch
        warning('EPS file could not be saved automatically.');
    end

    try
        savefig(fig, [outBase '.fig']);
    catch
        try
            saveas(fig, [outBase '.fig']);
        catch
            warning('FIG file could not be saved automatically.');
        end
    end

    try
        writetable(summary_table, [outBase '_summary.csv']);
    catch
        warning('Summary table CSV could not be saved automatically.');
    end

    try
        writetable(incidence_table, [outBase '_incidence.csv']);
    catch
        warning('Incidence table CSV could not be saved automatically.');
    end

    fprintf('Done: %s.png / .eps / .fig have been saved.\n', outBase);

    %% =========================================================
    % 10) Collect results
    %% =========================================================
    results = struct();
    results.pars = pars;

    results.lambda0 = lambda0;
    results.R0 = R0;

    results.lambda_d = lambda_d;
    results.Rd = Rd;
    results.xi_d = xi_d;

    results.lambda3 = lambda3;
    results.Rcdm = Rcdm;
    results.xi_cdm = xi_cdm;

    results.tPlot = tPlot;
    results.Lambda0_plot = Lambda0_plot;
    results.LambdaD_plot = LambdaD_plot;
    results.Lambda3_plot = Lambda3_plot;

    results.tau_d = tau_d;
    results.Fd = Fd;

    results.tau3 = tau3;
    results.F3 = F3;
    results.h1 = h1;
    results.h2 = h2;
    results.h3 = h3;

    results.summary_table = summary_table;
    results.incidence_table = incidence_table;
end

%% ========================================================================
% Default parameters
%% ========================================================================

function pars = default_pars_local()
    pars.beta   = 0.2653;
    pars.gamma  = 0.20;
    pars.EK     = 7.0455;
    pars.eps    = 0.5763;
    pars.m      = 0.2684;

    pars.mu_d    = 0.9420281179088986;
    pars.sigma_d = 0.8443162761021743;

    pars.tauMax = 30;
    pars.dt = 0.05;

    pars.lambdaL = -1.5;
    pars.lambdaU = 1.5;
    pars.lambdaExpandStep = 0.5;
    pars.lambdaExpandMax  = 16;

    pars.maxIterHazard = 300;
    pars.tolHazard = 1e-6;
    pars.relaxHazard = 0.50;

    pars.plot_tEnd = 8;
    pars.plot_dt   = 0.04;
end

%% ========================================================================
% Diagnosis-only scenario
%% ========================================================================

function [lambda_d, tau, Fd] = solve_lambda_diagnosis_only_local(pars)
    tau = (0:pars.dt:pars.tauMax)';
    hd = diagnosis_hazard_lognormal_local(tau, pars.mu_d, pars.sigma_d);
    Fd = exp(-cumtrapz(tau, hd));

    fun = @(lam) lotka_residual_diagnosis_only_local(lam, tau, Fd, pars);

    lambda_d = solve_scalar_root_local(fun, pars.lambdaL, pars.lambdaU, ...
        pars.lambdaExpandStep, pars.lambdaExpandMax);
end

function val = lotka_residual_diagnosis_only_local(lambda, tau, Fd, pars)
    theta = pars.EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-(pars.gamma + lambda) .* tau) .* Fd;
    val = trapz(tau, integrand) - 1;
end

%% ========================================================================
% Integrated NPIs scenario
%% ========================================================================

function [lambda3, tau, F3, h1, h2, h3] = solve_lambda_integrated_local(pars)

    fun = @(lam) lotka_residual_integrated_only_local(lam, pars);

    lambda3 = solve_scalar_root_local(fun, pars.lambdaL, pars.lambdaU, ...
        pars.lambdaExpandStep, pars.lambdaExpandMax);

    [~, tau, F3, h1, h2, h3] = lotka_residual_integrated_details_local(lambda3, pars);
end

function val = lotka_residual_integrated_only_local(lambda, pars)
    [val, ~, ~, ~, ~, ~] = lotka_residual_integrated_details_local(lambda, pars);
end

function [val, tau, F3, h1, h2, h3] = lotka_residual_integrated_details_local(lambda, pars)
    [tau, F3, h1, h2] = solve_F3_given_lambda_local(lambda, pars);
    theta = pars.EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-(pars.gamma + lambda) .* tau) .* F3;
    val = trapz(tau, integrand) - 1;
    z = pars.EK * (1 - exp(-pars.beta * tau));
    h3 = h1 + z .* h2;
end

%% ========================================================================
% Solve F3 for a given lambda
%% ========================================================================

function [tau, F3, h1, h2] = solve_F3_given_lambda_local(lambda, pars)
    tau = (0:pars.dt:pars.tauMax)';
    n = numel(tau);

    beta = pars.beta;
    epsi = pars.eps;
    m = pars.m;
    EK = pars.EK;
    gamma = pars.gamma;

    hd = diagnosis_hazard_lognormal_local(tau, pars.mu_d, pars.sigma_d);

    z = EK * (1 - exp(-beta * tau));
    theta = EK * beta * exp(-beta * tau);

    h1 = zeros(n, 1);
    h2 = zeros(n, 1);

    for iter = 1:pars.maxIterHazard
        h1_old = h1;
        h2_old = h2;

        Fd = exp(-cumtrapz(tau, hd));
        Fm = exp(-m * tau);

        Fc1 = exp(-cumtrapz(tau, h1_old));
        Fc2 = exp(-cumtrapz(tau, z .* h2_old));

        F1 = Fc1 .* Fd .* Fm;
        F2 = Fc2 .* Fd .* Fm;

        D1 = trapz(tau, exp(-(lambda + gamma) * tau) .* theta .* F1);
        D2 = trapz(tau, exp(-(lambda + gamma) * tau) .* theta .* F2);

        D1 = max(D1, 1e-12);
        D2 = max(D2, 1e-12);

        h1_new = zeros(n, 1);
        Q1 = F1 .* (h1_old + hd + m);

        for i = 1:n
            tau_shift = tau(i:end);
            a = tau_shift - tau(i);

            theta_a = EK * beta * exp(-beta * a);
            integrand = exp(-(lambda + gamma) * a) .* theta_a .* Q1(i:end);

            h1_new(i) = epsi / D1 * trapz_safe_local(a, integrand);
        end
        h1_new = max(h1_new, 0);

        h2_new = zeros(n, 1);
        R2 = F2 .* (z .* h2_old + hd + m);

        for i = 1:n
            b = tau(1:i);
            theta_b = EK * beta * exp(-beta * b);
            integrand = exp(-(lambda + gamma) * b) .* theta_b .* flipud(R2(1:i));

            h2_new(i) = epsi / D2 * trapz_safe_local(b, integrand);
        end
        h2_new = max(h2_new, 0);

        h1 = pars.relaxHazard * h1_old + (1 - pars.relaxHazard) * h1_new;
        h2 = pars.relaxHazard * h2_old + (1 - pars.relaxHazard) * h2_new;

        err = max([norm(h1 - h1_old, inf), norm(h2 - h2_old, inf)]);
        if err < pars.tolHazard
            break;
        end
    end

    hc3 = h1 + z .* h2;

    Fd = exp(-cumtrapz(tau, hd));
    Fm = exp(-m * tau);
    Fc3 = exp(-cumtrapz(tau, hc3));

    F3 = Fc3 .* Fd .* Fm;
end

%% ========================================================================
% Diagnosis hazard h_d(tau)
%% ========================================================================

function hd = diagnosis_hazard_lognormal_local(tau, mu, sigma)
    tau_safe = max(tau, 1e-12);

    logtau = log(tau_safe);
    pdf = exp(-((logtau - mu).^2) ./ (2 * sigma^2)) ./ ...
        (tau_safe * sigma * sqrt(2*pi));
    cdf = 0.5 * (1 + erf((logtau - mu) ./ (sigma * sqrt(2))));

    S = max(1 - cdf, 1e-12);
    hd = pdf ./ S;
    hd(tau == 0) = 0;
end

%% ========================================================================
% Generic scalar root solver
%% ========================================================================

function x = solve_scalar_root_local(fun, a, b, expandStep, expandMax)
    fa = fun(a);
    fb = fun(b);

    count = 0;
    while sign(fa) == sign(fb) && count < expandMax
        a = a - expandStep;
        b = b + expandStep;
        fa = fun(a);
        fb = fun(b);
        count = count + 1;
    end

    opts = optimset('Display', 'off');

    if sign(fa) ~= sign(fb)
        x = fzero(fun, [a, b], opts);
    else
        obj = @(z) fun(z).^2;
        x = fminbnd(obj, a, b, opts);
    end
end

%% ========================================================================
% Manual legend: tighter upper-left
%% ========================================================================

function draw_manual_legend_local(ax, col_orange, col_blue, col_yellow)
    xl = xlim(ax);
    yl = ylim(ax);

    % move legend tighter to upper-left
    x0 = xl(1) + 0.03 * (xl(2) - xl(1));
    x1 = xl(1) + 0.15 * (xl(2) - xl(1));
    tx = xl(1) + 0.18 * (xl(2) - xl(1));

    y_top = yl(2);
    y_bot = yl(1);

    y1 = 10^(log10(y_bot) + 0.93 * (log10(y_top) - log10(y_bot)));
    y2 = 10^(log10(y_bot) + 0.86 * (log10(y_top) - log10(y_bot)));
    y3 = 10^(log10(y_bot) + 0.79 * (log10(y_top) - log10(y_bot)));

    plot(ax, [x0 x1], [y1 y1], '-', 'Color', col_orange, 'LineWidth', 2.4);
    text(ax, tx, y1, 'No intervention', ...
        'VerticalAlignment', 'middle', 'FontSize', 10);

    plot(ax, [x0 x1], [y2 y2], '-', 'Color', col_blue, 'LineWidth', 2.4);
    text(ax, tx, y2, 'Diagnosis only', ...
        'VerticalAlignment', 'middle', 'FontSize', 10);

    plot(ax, [x0 x1], [y3 y3], '-', 'Color', col_yellow, 'LineWidth', 2.6);
    text(ax, tx, y3, 'Integrated NPIs', ...
        'VerticalAlignment', 'middle', 'FontSize', 10);
end

%% ========================================================================
% Safe trapz
%% ========================================================================

function val = trapz_safe_local(x, y)
    x = x(:);
    y = y(:);

    if numel(x) <= 1 || numel(y) <= 1
        val = 0;
    else
        val = trapz(x, y);
    end
end