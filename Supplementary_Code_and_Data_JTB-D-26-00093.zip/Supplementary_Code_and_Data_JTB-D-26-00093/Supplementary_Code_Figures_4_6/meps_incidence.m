function results = meps_incidence()
%MEPS_INCIDENCE
% Figure for Section 5.3.2:
% Impact of mass screening rate m and tracing coverage eps
% on early-phase incidence under integrated NPIs.
%
% Panel (a): heatmap of log10(I_T), where
%            I_T = Lambda_3(T) / Lambda_3(0) = exp(lambda3 * T)
%
% Panel (b): normalized incidence trajectories for several eps values,
%            with m fixed at the baseline value.
%
% No call to legend() is used, to avoid local MATLAB conflicts.

    clc;
    close all;

    %% =========================================================
    % 1) Baseline parameters
    %% =========================================================
    pars = default_pars_local();

    % fixed time horizon for panel (a)
    Tfix = 8;   % days

    %% =========================================================
    % 2) Grid for heatmap
    %% =========================================================
    epsGrid = linspace(0.10, 0.90, 33);
    mGrid   = linspace(0.05, 0.60, 33);

    lambdaMat = nan(length(mGrid), length(epsGrid));
    ITMat     = nan(length(mGrid), length(epsGrid));

    fprintf('\n============================================================\n');
    fprintf('Computing heatmap for Section 5.3.2\n');
    fprintf('Grid size: %d x %d\n', length(mGrid), length(epsGrid));
    fprintf('Fixed time horizon T = %.2f days\n', Tfix);
    fprintf('============================================================\n');

    for i = 1:length(mGrid)
        for j = 1:length(epsGrid)
            pars_tmp = pars;
            pars_tmp.m = mGrid(i);
            pars_tmp.eps = epsGrid(j);

            lambda3 = solve_lambda_integrated_local(pars_tmp);
            lambdaMat(i,j) = lambda3;
            ITMat(i,j) = exp(lambda3 * Tfix);
        end
    end

    log10ITMat = log10(ITMat);

    %% =========================================================
    % 3) Curves for panel (b)
    %% =========================================================
    epsList = [0.20, 0.40, pars.eps, 0.80];
    tPlot = (0:pars.plot_dt:pars.plot_tEnd)';
    trajMat = nan(length(tPlot), length(epsList));
    lambdaList = nan(size(epsList));

    for k = 1:length(epsList)
        pars_tmp = pars;
        pars_tmp.eps = epsList(k);
        lambda_tmp = solve_lambda_integrated_local(pars_tmp);

        lambdaList(k) = lambda_tmp;
        trajMat(:,k) = exp(lambda_tmp * tPlot);
    end

    %% =========================================================
    % 4) Print concise summary
    %% =========================================================
    fprintf('\nBaseline m = %.4f\n', pars.m);
    fprintf('Trajectory panel uses eps = ');
    fprintf('%.3f ', epsList);
    fprintf('\nCorresponding lambda3 values:\n');
    for k = 1:length(epsList)
        fprintf('  eps = %.3f  -> lambda3 = %.6f\n', epsList(k), lambdaList(k));
    end
    fprintf('\n');

    %% =========================================================
    % 5) Save tables
    %% =========================================================
    [EPS, MM] = meshgrid(epsGrid, mGrid);

    heatmap_table = table(EPS(:), MM(:), lambdaMat(:), ITMat(:), log10ITMat(:), ...
        'VariableNames', {'epsilon', 'm', 'lambda3', 'I_T', 'log10_I_T'});

    traj_table = table(tPlot, trajMat(:,1), trajMat(:,2), trajMat(:,3), trajMat(:,4), ...
        'VariableNames', {'Time', ...
        sprintf('eps_%03d', round(100*epsList(1))), ...
        sprintf('eps_%03d', round(100*epsList(2))), ...
        sprintf('eps_%03d', round(100*epsList(3))), ...
        sprintf('eps_%03d', round(100*epsList(4)))} );

    %% =========================================================
    % 6) Plot figure
    %% =========================================================
    fig = figure('Color', 'w');
    set(fig, 'Position', [80 80 1200 500]);

    %% -------------------------
    % Panel (a): heatmap
    %% -------------------------
    ax1 = subplot(1,2,1);
    hold(ax1, 'on');

    contourf(ax1, epsGrid, mGrid, log10ITMat, 16, 'LineColor', 'none');
    colormap(ax1, parula(16));

    cb = colorbar(ax1);
    cb.Label.Interpreter = 'tex';
    cb.Label.String = 'log_{10}(\Lambda_3(8)/\Lambda_3(0))';
    cb.Label.FontSize = 10;

    xlabel(ax1, '\epsilon', 'FontSize', 12);
    ylabel(ax1, 'm', 'FontSize', 12);

    box(ax1, 'on');
    grid(ax1, 'on');
    ax1.FontSize = 11;
    ax1.LineWidth = 1.0;
    ax1.TickDir = 'out';

    % baseline point
    plot(ax1, pars.eps, pars.m, 'wo', ...
        'MarkerFaceColor', 'w', ...
        'MarkerSize', 6.5, ...
        'LineWidth', 1.0);

    text(ax1, pars.eps + 0.015, pars.m, 'baseline', ...
        'Color', [0 0 0], ...
        'FontSize', 10, ...
        'FontWeight', 'bold', ...
        'BackgroundColor', [1 1 1], ...
        'Margin', 1);

    title(ax1, '(a)', 'FontSize', 12, 'FontWeight', 'normal');

    %% -------------------------
    % Panel (b): trajectories
    %% -------------------------
    ax2 = subplot(1,2,2);
    hold(ax2, 'on');

    cols = [ ...
        0.80 0.35 0.10;   % orange-brown
        0.35 0.65 0.90;   % light blue
        0.20 0.60 0.30;   % green (baseline)
        0.60 0.35 0.75];  % purple

    for k = 1:length(epsList)
        plot(ax2, tPlot, trajMat(:,k), '-', ...
            'Color', cols(k,:), 'LineWidth', 2.2);
    end

    set(ax2, 'YScale', 'log');

    xlabel(ax2, 'Time (days)', 'FontSize', 12);
    ylabel(ax2, 'Normalized daily incidence (log scale)', 'FontSize', 12);

    xlim(ax2, [0 pars.plot_tEnd]);

    ymin = min(trajMat(:));
    ymax = max(trajMat(:));
    ylim(ax2, [max(ymin,1e-8), 1.12*ymax]);

    box(ax2, 'on');
    grid(ax2, 'on');
    ax2.FontSize = 11;
    ax2.LineWidth = 1.0;
    ax2.TickDir = 'out';

    title(ax2, '(b)', 'FontSize', 12, 'FontWeight', 'normal');

    draw_manual_legend_eps_local(ax2, epsList, cols, pars.eps);

    %% =========================================================
    % 7) Export
    %% =========================================================
    outBase = 'meps_incidence_JTB';

    try
        print(fig, [outBase '.png'], '-dpng', '-r600');
    catch
        try
            saveas(fig, [outBase '.png']);
        catch
            warning('PNG file could not be saved automatically.');
        end
    end

    try
        print(fig, [outBase '.eps'], '-depsc2', '-r600');
    catch
        warning('EPS file could not be saved automatically.');
    end

    try
        savefig(fig, [outBase '.fig']);
    catch
        try
            saveas(fig, [outBase '.fig']);
        catch
            warning('FIG file could not be saved automatically.');
        end
    end

    try
        writetable(heatmap_table, [outBase '_heatmap.csv']);
    catch
        warning('Heatmap CSV could not be saved automatically.');
    end

    try
        writetable(traj_table, [outBase '_trajectories.csv']);
    catch
        warning('Trajectory CSV could not be saved automatically.');
    end

    fprintf('Done: %s.png / .eps / .fig have been saved.\n', outBase);

    %% =========================================================
    % 8) Return results
    %% =========================================================
    results = struct();
    results.pars = pars;
    results.Tfix = Tfix;
    results.epsGrid = epsGrid;
    results.mGrid = mGrid;
    results.lambdaMat = lambdaMat;
    results.ITMat = ITMat;
    results.log10ITMat = log10ITMat;

    results.epsList = epsList;
    results.lambdaList = lambdaList;
    results.tPlot = tPlot;
    results.trajMat = trajMat;

    results.heatmap_table = heatmap_table;
    results.traj_table = traj_table;
end

%% ========================================================================
% Default parameters
%% ========================================================================

function pars = default_pars_local()
    pars.beta   = 0.2653;
    pars.gamma  = 0.20;
    pars.EK     = 7.0455;
    pars.eps    = 0.5763;
    pars.m      = 0.2684;

    pars.mu_d    = 0.9420281179088986;
    pars.sigma_d = 0.8443162761021743;

    pars.tauMax = 30;
    pars.dt = 0.05;

    pars.lambdaL = -1.5;
    pars.lambdaU = 1.5;
    pars.lambdaExpandStep = 0.5;
    pars.lambdaExpandMax  = 16;

    pars.maxIterHazard = 300;
    pars.tolHazard = 1e-6;
    pars.relaxHazard = 0.50;

    pars.plot_tEnd = 8;
    pars.plot_dt   = 0.04;
end

%% ========================================================================
% Solve lambda3 under integrated NPIs
%% ========================================================================

function lambda3 = solve_lambda_integrated_local(pars)
    fun = @(lam) lotka_residual_integrated_only_local(lam, pars);
    lambda3 = solve_scalar_root_local(fun, pars.lambdaL, pars.lambdaU, ...
        pars.lambdaExpandStep, pars.lambdaExpandMax);
end

function val = lotka_residual_integrated_only_local(lambda, pars)
    [tau, F3] = solve_F3_given_lambda_local(lambda, pars);
    theta = pars.EK * pars.beta * exp(-pars.beta * tau);
    integrand = theta .* exp(-(pars.gamma + lambda) .* tau) .* F3;
    val = trapz(tau, integrand) - 1;
end

%% ========================================================================
% Solve F3 for a given lambda
%% ========================================================================

function [tau, F3] = solve_F3_given_lambda_local(lambda, pars)
    tau = (0:pars.dt:pars.tauMax)';
    n = numel(tau);

    beta = pars.beta;
    epsi = pars.eps;
    m = pars.m;
    EK = pars.EK;
    gamma = pars.gamma;

    hd = diagnosis_hazard_lognormal_local(tau, pars.mu_d, pars.sigma_d);

    z = EK * (1 - exp(-beta * tau));
    theta = EK * beta * exp(-beta * tau);

    h1 = zeros(n, 1);
    h2 = zeros(n, 1);

    for iter = 1:pars.maxIterHazard
        h1_old = h1;
        h2_old = h2;

        Fd = exp(-cumtrapz(tau, hd));
        Fm = exp(-m * tau);

        Fc1 = exp(-cumtrapz(tau, h1_old));
        Fc2 = exp(-cumtrapz(tau, z .* h2_old));

        F1 = Fc1 .* Fd .* Fm;
        F2 = Fc2 .* Fd .* Fm;

        D1 = trapz(tau, exp(-(lambda + gamma) * tau) .* theta .* F1);
        D2 = trapz(tau, exp(-(lambda + gamma) * tau) .* theta .* F2);

        D1 = max(D1, 1e-12);
        D2 = max(D2, 1e-12);

        % update h1
        h1_new = zeros(n, 1);
        Q1 = F1 .* (h1_old + hd + m);

        for i = 1:n
            tau_shift = tau(i:end);
            a = tau_shift - tau(i);

            theta_a = EK * beta * exp(-beta * a);
            integrand = exp(-(lambda + gamma) * a) .* theta_a .* Q1(i:end);

            h1_new(i) = epsi / D1 * trapz_safe_local(a, integrand);
        end
        h1_new = max(h1_new, 0);

        % update h2
        h2_new = zeros(n, 1);
        R2 = F2 .* (z .* h2_old + hd + m);

        for i = 1:n
            b = tau(1:i);
            theta_b = EK * beta * exp(-beta * b);
            integrand = exp(-(lambda + gamma) * b) .* theta_b .* flipud(R2(1:i));

            h2_new(i) = epsi / D2 * trapz_safe_local(b, integrand);
        end
        h2_new = max(h2_new, 0);

        % relaxation
        h1 = pars.relaxHazard * h1_old + (1 - pars.relaxHazard) * h1_new;
        h2 = pars.relaxHazard * h2_old + (1 - pars.relaxHazard) * h2_new;

        err = max([norm(h1 - h1_old, inf), norm(h2 - h2_old, inf)]);
        if err < pars.tolHazard
            break;
        end
    end

    if iter == pars.maxIterHazard && err >= pars.tolHazard
        warning('Hazard iteration may not have fully converged.');
    end

    hc3 = h1 + z .* h2;

    Fd = exp(-cumtrapz(tau, hd));
    Fm = exp(-m * tau);
    Fc3 = exp(-cumtrapz(tau, hc3));

    F3 = Fc3 .* Fd .* Fm;
end

%% ========================================================================
% Diagnosis hazard
%% ========================================================================

function hd = diagnosis_hazard_lognormal_local(tau, mu, sigma)
    tau_safe = max(tau, 1e-12);

    logtau = log(tau_safe);
    pdf = exp(-((logtau - mu).^2) ./ (2 * sigma^2)) ./ ...
        (tau_safe * sigma * sqrt(2*pi));
    cdf = 0.5 * (1 + erf((logtau - mu) ./ (sigma * sqrt(2))));

    S = max(1 - cdf, 1e-12);
    hd = pdf ./ S;
    hd(tau == 0) = 0;
end

%% ========================================================================
% Scalar root solver
%% ========================================================================

function x = solve_scalar_root_local(fun, a, b, expandStep, expandMax)
    fa = fun(a);
    fb = fun(b);

    count = 0;
    while sign(fa) == sign(fb) && count < expandMax
        a = a - expandStep;
        b = b + expandStep;
        fa = fun(a);
        fb = fun(b);
        count = count + 1;
    end

    opts = optimset('Display', 'off');

    if sign(fa) ~= sign(fb)
        x = fzero(fun, [a, b], opts);
    else
        obj = @(z) fun(z).^2;
        x = fminbnd(obj, a, b, opts);
    end
end

%% ========================================================================
% Manual legend for panel (b)
%% ========================================================================

function draw_manual_legend_eps_local(ax, epsList, cols, epsBaseline)
    xl = xlim(ax);
    yl = ylim(ax);

    x0 = xl(1) + 0.05 * (xl(2) - xl(1));
    x1 = xl(1) + 0.17 * (xl(2) - xl(1));
    tx = xl(1) + 0.20 * (xl(2) - xl(1));

    y_top = yl(2);
    y_bot = yl(1);

    yvec = zeros(length(epsList),1);
    for k = 1:length(epsList)
        yvec(k) = 10^(log10(y_bot) + (0.92 - 0.08*(k-1)) * (log10(y_top) - log10(y_bot)));
    end

    for k = 1:length(epsList)
        plot(ax, [x0 x1], [yvec(k) yvec(k)], '-', ...
            'Color', cols(k,:), 'LineWidth', 2.2);

        if abs(epsList(k) - epsBaseline) < 1e-10
            labelStr = sprintf('\\epsilon = %.3f (baseline)', epsList(k));
        else
            labelStr = sprintf('\\epsilon = %.3f', epsList(k));
        end

        text(ax, tx, yvec(k), labelStr, ...
            'VerticalAlignment', 'middle', 'FontSize', 10);
    end
end

%% ========================================================================
% Safe trapz
%% ========================================================================

function val = trapz_safe_local(x, y)
    x = x(:);
    y = y(:);

    if numel(x) <= 1 || numel(y) <= 1
        val = 0;
    else
        val = trapz(x, y);
    end
end